package com.example.project_appsss;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public String selectedDeliveryAddress = "";
    public MapManager mapManager = new MapManager();

    // Firebase Database Regional URL
    public static final String DB_URL = "https://sarifresh-92485-default-rtdb.asia-southeast1.firebasedatabase.app";

    // Dynamic User Credentials (Populated during Registration / Google Sign-In)
    public String registeredEmail = "";
    public String registeredPassword = "";
    public String registeredName = "";
    public String registeredPhone = "";

    // User Phone Verification State (Default: Unverified)
    public boolean isPhoneVerified = false;

    // ==========================================
    // DATA MODELS
    // ==========================================
    public static class CartItem {
        public String itemName;
        public int quantity;
        public String unitLabel;   // e.g. "kg", "sack (25kg)", "full tray (30pcs)", "bottle (1000ml)", "pack"
        public double unitPrice;   // Price per unit selection

        public CartItem() {} // Default constructor for Firebase

        public CartItem(String itemName, int quantity, String unitLabel, double unitPrice) {
            this.itemName = itemName;
            this.quantity = quantity;
            this.unitLabel = unitLabel;
            this.unitPrice = unitPrice;
        }

        public double getTotalPrice() {
            return quantity * unitPrice;
        }
    }

    public static class ProductItem {
        public String id;
        public String name;
        public String category;
        public double price;
        public String unit;
        public boolean isAvailable;

        public ProductItem() {} // Default constructor for Firebase

        public ProductItem(String id, String name, String category, double price, String unit, boolean isAvailable) {
            this.id = id;
            this.name = name;
            this.category = category;
            this.price = price;
            this.unit = unit;
            this.isAvailable = isAvailable;
        }

        public ProductItem(String name, double price, String unit, boolean isAvailable) {
            this("", name, "", price, unit, isAvailable);
        }
    }

    public static class CustomerOrder {
        public String orderId;
        public String customerName;
        public String contactNumber;
        public String deliveryAddress;
        public String specialInstructions;
        public List<CartItem> items;
        public int totalAmount;
        public String status; // "PENDING", "ACCEPTED", "REJECTED"
        public boolean isPhoneVerified;
        public String paymentMethod; // "Cash on Delivery" or "GCash (Cashless)"

        public CustomerOrder() {} // Default constructor for Firebase

        // Primary Constructor with Payment Method
        public CustomerOrder(String name, String phone, String address, String notes, List<CartItem> items, int totalAmount, boolean isPhoneVerified, String paymentMethod) {
            this.customerName = name;
            this.contactNumber = phone;
            this.deliveryAddress = address;
            this.specialInstructions = notes;
            this.items = new ArrayList<>(items);
            this.totalAmount = totalAmount;
            this.status = "PENDING";
            this.isPhoneVerified = isPhoneVerified;
            this.paymentMethod = paymentMethod;
        }

        // Overloaded Constructor (Defaults to Cash on Delivery)
        public CustomerOrder(String name, String phone, String address, String notes, List<CartItem> items, int totalAmount, boolean isPhoneVerified) {
            this(name, phone, address, notes, items, totalAmount, isPhoneVerified, "Cash on Delivery");
        }
    }

    // CUSTOMER REPORTED ISSUES MODEL
    public static class IssueReport {
        public String reportId;
        public String user;
        public String issueType;
        public String orderRef;
        public String description;
        public long timestamp;

        public IssueReport() {} // Required for Firebase

        public IssueReport(String reportId, String user, String issueType, String orderRef, String description, long timestamp) {
            this.reportId = reportId;
            this.user = user;
            this.issueType = issueType;
            this.orderRef = orderRef;
            this.description = description;
            this.timestamp = timestamp;
        }
    }

    // SHARED LISTS
    public final List<CartItem> cartList = new ArrayList<>();
    public final List<CustomerOrder> adminOrderQueue = new ArrayList<>();
    public final List<ProductItem> storeInventory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ENABLE IMMERSIVE FULL-SCREEN MODE
        enableFullScreen();

        // Synchronize default store inventory with Firebase
        initializeFirebaseInventory();

        showStartOrderScreen();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enableFullScreen();
        }
    }

    // ==========================================
    // IMMERSIVE FULL-SCREEN HELPER
    // ==========================================
    private void enableFullScreen() {
        try {
            if (getWindow() != null) {
                getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);

                if (getWindow().getDecorView() != null) {
                    getWindow().getDecorView().setSystemUiVisibility(
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Dynamic Initials Generator (e.g. "Maria Santos" -> "MS")
    public String getInitials(String name) {
        if (name == null || name.trim().isEmpty()) return "G";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase();
        }
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase();
    }

    // Calculate total quantity of all items in cart
    private int getTotalCartCount() {
        int count = 0;
        for (CartItem item : cartList) {
            count += item.quantity;
        }
        return count;
    }

    // Dynamic Red Badge Updater
    public void updateCartBadges() {
        int totalCount = getTotalCartCount();

        TextView tvCartBadge = findViewById(R.id.tvCartBadge);
        TextView tvNavOrdersBadge = findViewById(R.id.tvNavOrdersBadge);

        if (tvCartBadge != null) {
            if (totalCount > 0) {
                tvCartBadge.setText(String.valueOf(totalCount));
                tvCartBadge.setVisibility(View.VISIBLE);
            } else {
                tvCartBadge.setVisibility(View.GONE);
            }
        }

        if (tvNavOrdersBadge != null) {
            if (totalCount > 0) {
                tvNavOrdersBadge.setText(String.valueOf(totalCount));
                tvNavOrdersBadge.setVisibility(View.VISIBLE);
            } else {
                tvNavOrdersBadge.setVisibility(View.GONE);
            }
        }
    }

    // ==========================================
    // SCREEN NAVIGATION ROUTING
    // ==========================================
    private void showStartOrderScreen() {
        setContentView(R.layout.start_order);
        Button btnStartOrder = findViewById(R.id.btnStartOrdering);
        if (btnStartOrder != null) {
            btnStartOrder.setOnClickListener(v -> showLoginScreen());
        }
    }

    public void showLoginScreen() {
        new login_area().setupLogin(this);
    }

    public void showRegisterScreen() {
        new register_area().setupRegister(this);
    }

    public void showHomeScreen() {
        new home_shopping().setupHome(this);
    }

    public void showOrdersScreen() {
        new oder_area().setupOrder(this);
    }

    public void showProfileScreen() {
        new user_profile_area().setupProfile(this);
    }

    public void showMapScreen() {
        new store_and_delivery().setupStoreAndDelivery(this);
    }

    public void showPhoneVerificationScreen() {
        new phone_verification_area().setupVerification(this);
    }

    public void showAdminScreen() {
        new admin_area().setupAdmin(this);
    }

    public void showOrderHistoryScreen() {
        new order_history_area().setupHistory(this);
    }

    public void showReportIssueScreen() {
        new report_issue_area().setupReportIssue(this);
    }

    // ADD ITEM TO CART HELPER METHOD
    public void addItemToCart(String itemName, int qty, String unitLabel, double pricePerUnit) {
        boolean exists = false;
        for (CartItem item : cartList) {
            if (item.itemName.equalsIgnoreCase(itemName) && item.unitLabel.equalsIgnoreCase(unitLabel)) {
                item.quantity += qty;
                exists = true;
                break;
            }
        }

        if (!exists) {
            cartList.add(new CartItem(itemName, qty, unitLabel, pricePerUnit));
        }

        Toast.makeText(this, "Added " + qty + " " + unitLabel + " of " + itemName + " to cart!", Toast.LENGTH_SHORT).show();
        updateCartBadges();
    }

    // ==========================================
    // GOOGLE SIGN-IN RESULT HANDLER
    // ==========================================
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 9001) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null) {
                    firebaseAuthWithGoogle(account.getIdToken(), account.getDisplayName(), account.getEmail());
                }
            } catch (ApiException e) {
                Toast.makeText(this, "Google Sign-In Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken, String displayName, String email) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        FirebaseAuth.getInstance().signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        if (user != null) {
                            String uid = user.getUid();
                            registeredName = (displayName != null && !displayName.isEmpty()) ? displayName : "Google User";
                            registeredEmail = (email != null && !email.isEmpty()) ? email : "";

                            // Save user node in Realtime Database
                            Map<String, Object> userMap = new HashMap<>();
                            userMap.put("name", registeredName);
                            userMap.put("email", registeredEmail);

                            FirebaseDatabase.getInstance(DB_URL)
                                    .getReference("users")
                                    .child(uid)
                                    .setValue(userMap);

                            Toast.makeText(MainActivity.this, "Welcome, " + registeredName + "!", Toast.LENGTH_SHORT).show();
                            showHomeScreen();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Authentication Failed.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // ==========================================
    // FIREBASE INVENTORY SETUP
    // ==========================================
    private void initializeFirebaseInventory() {
        DatabaseReference productsRef = FirebaseDatabase.getInstance(DB_URL).getReference("products");

        productsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                storeInventory.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot itemSnap : snapshot.getChildren()) {
                        ProductItem item = itemSnap.getValue(ProductItem.class);
                        if (item != null) {
                            item.id = itemSnap.getKey();
                            storeInventory.add(item);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Failed to load store inventory.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ==========================================
    // DYNAMIC CATEGORY SCREENS NAVIGATION
    // ==========================================
    public void showRiceScreen() {
        setContentView(R.layout.rice);
        setupCategoryScreenNavigation();
        loadDynamicCategoryItems(R.id.containerRiceList, "Rice");
    }

    public void showEggsScreen() {
        setContentView(R.layout.eggs);
        setupCategoryScreenNavigation();
        loadDynamicCategoryItems(R.id.containerEggsList, "Eggs");
    }

    public void showOilScreen() {
        setContentView(R.layout.oil);
        setupCategoryScreenNavigation();
        loadDynamicCategoryItems(R.id.containerOilList, "Oils");
    }

    public void showFrozenScreen() {
        setContentView(R.layout.frozen);
        setupCategoryScreenNavigation();
        loadDynamicCategoryItems(R.id.containerFrozenList, "Frozen");
    }

    // ==========================================
    // DYNAMIC FIREBASE CATEGORY ITEM RENDERER
    // ==========================================
    private void loadDynamicCategoryItems(int containerId, String categoryName) {
        LinearLayout container = findViewById(containerId);
        if (container == null) return;

        DatabaseReference productsRef = FirebaseDatabase.getInstance(DB_URL).getReference("products");

        productsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                container.removeAllViews();

                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    showEmptyCategoryMessage(container, categoryName);
                    return;
                }

                int availableCount = 0;

                for (DataSnapshot itemSnap : snapshot.getChildren()) {
                    ProductItem product = itemSnap.getValue(ProductItem.class);

                    if (product != null && categoryName.equalsIgnoreCase(product.category) && product.isAvailable) {
                        product.id = itemSnap.getKey();
                        availableCount++;

                        CardView card = new CardView(MainActivity.this);
                        CardView.LayoutParams cardParams = new CardView.LayoutParams(
                                CardView.LayoutParams.MATCH_PARENT, CardView.LayoutParams.WRAP_CONTENT);
                        cardParams.setMargins(0, 0, 0, 16);
                        card.setLayoutParams(cardParams);
                        card.setRadius(16);
                        card.setCardBackgroundColor(Color.WHITE);
                        card.setCardElevation(2);

                        LinearLayout itemRow = new LinearLayout(MainActivity.this);
                        itemRow.setOrientation(LinearLayout.HORIZONTAL);
                        itemRow.setPadding(24, 24, 24, 24);
                        itemRow.setGravity(Gravity.CENTER_VERTICAL);

                        LinearLayout detailsLayout = new LinearLayout(MainActivity.this);
                        detailsLayout.setOrientation(LinearLayout.VERTICAL);
                        LinearLayout.LayoutParams detParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                        detailsLayout.setLayoutParams(detParams);

                        TextView tvName = new TextView(MainActivity.this);
                        tvName.setText(product.name);
                        tvName.setTextSize(15);
                        tvName.setTypeface(null, Typeface.BOLD);
                        tvName.setTextColor(Color.parseColor("#1A1A1A"));

                        TextView tvPrice = new TextView(MainActivity.this);
                        tvPrice.setText("₱" + String.format("%.2f", product.price) + " / " + product.unit);
                        tvPrice.setTextSize(13);
                        tvPrice.setTextColor(Color.parseColor("#666666"));

                        detailsLayout.addView(tvName);
                        detailsLayout.addView(tvPrice);

                        final int[] quantity = {1};

                        TextView btnMinus = createCounterBtn("-");
                        TextView tvQty = new TextView(MainActivity.this);
                        tvQty.setText("1");
                        tvQty.setTextSize(14);
                        tvQty.setTypeface(null, Typeface.BOLD);
                        tvQty.setPadding(16, 0, 16, 0);

                        TextView btnPlus = createCounterBtn("+");

                        btnMinus.setOnClickListener(v -> {
                            if (quantity[0] > 1) {
                                quantity[0]--;
                                tvQty.setText(String.valueOf(quantity[0]));
                            }
                        });

                        btnPlus.setOnClickListener(v -> {
                            quantity[0]++;
                            tvQty.setText(String.valueOf(quantity[0]));
                        });

                        TextView btnAdd = new TextView(MainActivity.this);
                        btnAdd.setText("Add");
                        btnAdd.setTextSize(13);
                        btnAdd.setTypeface(null, Typeface.BOLD);
                        btnAdd.setTextColor(Color.WHITE);
                        btnAdd.setBackgroundColor(Color.parseColor("#2A4836"));
                        btnAdd.setPadding(32, 16, 32, 16);

                        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        addParams.setMargins(16, 0, 0, 0);
                        btnAdd.setLayoutParams(addParams);

                        // SHOW CATEGORY-SPECIFIC UNIT DIALOG ON CLICK
                        btnAdd.setOnClickListener(v -> showUnitSelectionDialog(product, quantity[0]));

                        itemRow.addView(detailsLayout);
                        itemRow.addView(btnMinus);
                        itemRow.addView(tvQty);
                        itemRow.addView(btnPlus);
                        itemRow.addView(btnAdd);

                        card.addView(itemRow);
                        container.addView(card);
                    }
                }

                if (availableCount == 0) {
                    showEmptyCategoryMessage(container, categoryName);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Failed to load products: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ==========================================
    // DYNAMIC UNIT SELECTION DIALOG
    // ==========================================
    private void showUnitSelectionDialog(ProductItem product, int quantity) {
        String category = product.category != null ? product.category.toLowerCase() : "";
        String[] options;
        double[] priceMultipliers;
        String[] unitLabels;

        switch (category) {
            case "rice":
                options = new String[]{"By Kilo (1kg)", "1 Sack (25kg)"};
                priceMultipliers = new double[]{1.0, 25.0};
                unitLabels = new String[]{"kg", "sack (25kg)"};
                break;

            case "eggs":
                options = new String[]{"Half Tray (15pcs)", "Full Tray (30pcs)"};
                priceMultipliers = new double[]{15.0, 30.0};
                unitLabels = new String[]{"half tray (15pcs)", "full tray (30pcs)"};
                break;

            case "oils":
            case "oil":
                options = new String[]{"Bottle (500ml)", "Bottle (1000ml)"};
                priceMultipliers = new double[]{1.0, 2.0};
                unitLabels = new String[]{"bottle (500ml)", "bottle (1000ml)"};
                break;

            case "frozen":
                options = new String[]{"By Pack", "By Box"};
                priceMultipliers = new double[]{1.0, 10.0};
                unitLabels = new String[]{"pack", "box"};
                break;

            default:
                addItemToCart(product.name, quantity, product.unit, product.price);
                return;
        }

        final int[] selectedIndex = {0};

        new AlertDialog.Builder(this)
                .setTitle("Select Option for " + product.name)
                .setSingleChoiceItems(options, 0, (dialog, which) -> selectedIndex[0] = which)
                .setPositiveButton("Add to Cart", (dialog, which) -> {
                    int index = selectedIndex[0];
                    double finalUnitPrice = product.price * priceMultipliers[index];
                    String selectedUnit = unitLabels[index];

                    addItemToCart(product.name, quantity, selectedUnit, finalUnitPrice);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private TextView createCounterBtn(String symbol) {
        TextView btn = new TextView(this);
        btn.setText(symbol);
        btn.setTextSize(16);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setTextColor(Color.parseColor("#2A4836"));
        btn.setBackgroundColor(Color.parseColor("#E3EBDC"));
        btn.setPadding(20, 8, 20, 8);
        btn.setGravity(Gravity.CENTER);
        return btn;
    }

    private void showEmptyCategoryMessage(LinearLayout container, String categoryName) {
        TextView tvEmpty = new TextView(this);
        tvEmpty.setText("No " + categoryName + " products currently available.");
        tvEmpty.setTextColor(Color.GRAY);
        tvEmpty.setTextSize(14);
        tvEmpty.setPadding(0, 48, 0, 0);
        tvEmpty.setGravity(Gravity.CENTER);
        container.addView(tvEmpty);
    }

    private void setupCategoryScreenNavigation() {
        ImageView btnBack = findViewById(R.id.btnBackToHome);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> showHomeScreen());
        }

        ImageView btnCart = findViewById(R.id.btnCartInCategory);
        if (btnCart != null) {
            btnCart.setOnClickListener(v -> showOrdersScreen());
        }

        setupBottomNav();
    }

    public void setupBottomNav() {
        LinearLayout navHome = findViewById(R.id.navCategoryHome);
        LinearLayout navMap = findViewById(R.id.navCategoryMap);
        LinearLayout navOrders = findViewById(R.id.navCategoryOrders);
        LinearLayout navProfile = findViewById(R.id.navCategoryProfile);

        if (navHome != null) {
            navHome.setOnClickListener(v -> showHomeScreen());
        }
        if (navMap != null) {
            navMap.setOnClickListener(v -> showMapScreen());
        }
        if (navOrders != null) {
            navOrders.setOnClickListener(v -> showOrdersScreen());
        }
        if (navProfile != null) {
            navProfile.setOnClickListener(v -> showProfileScreen());
        }

        updateCartBadges();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapManager.onResume();
    }

    @Override
    protected void onPause() {
        mapManager.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        mapManager.onDestroy();
        super.onDestroy();
    }
}