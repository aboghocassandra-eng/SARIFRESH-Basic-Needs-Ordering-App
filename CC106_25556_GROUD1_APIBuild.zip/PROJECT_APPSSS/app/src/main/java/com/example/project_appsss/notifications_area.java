package com.example.project_appsss;

import com.example.project_appsss.R;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class notifications_area {

    public void setupNotifications(MainActivity activity) {
        activity.setContentView(R.layout.notification_area);

        View btnBackFromNotifications = activity.findViewById(R.id.btnBackFromNotifications);
        TextView btnMarkAllRead = activity.findViewById(R.id.btnMarkAllRead);
        LinearLayout llNotificationsList = activity.findViewById(R.id.llNotificationsList);
        TextView tvEmptyNotifications = activity.findViewById(R.id.tvEmptyNotifications);

        Switch switchOrderUpdates = activity.findViewById(R.id.switchOrderUpdates);
        Switch switchPromos = activity.findViewById(R.id.switchPromos);

        // ====================================================
        // BACK BUTTON LOGIC (NAVIGATES BACK TO PROFILE)
        // ====================================================
        if (btnBackFromNotifications != null) {
            btnBackFromNotifications.setOnClickListener(v -> new user_profile_area().setupProfile(activity));
        }

        // ====================================================
        // CLEAR ALL NOTIFICATIONS ACTION
        // ====================================================
        if (btnMarkAllRead != null) {
            btnMarkAllRead.setOnClickListener(v -> {
                if (llNotificationsList != null && llNotificationsList.getVisibility() == View.VISIBLE) {
                    llNotificationsList.setVisibility(View.GONE);
                    if (tvEmptyNotifications != null) {
                        tvEmptyNotifications.setVisibility(View.VISIBLE);
                    }
                    Toast.makeText(activity, "Notifications cleared", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "No notifications to clear", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // ====================================================
        // PREFERENCE SWITCH TOGGLES
        // ====================================================
        if (switchOrderUpdates != null) {
            switchOrderUpdates.setOnCheckedChangeListener((buttonView, isChecked) -> {
                String state = isChecked ? "enabled" : "disabled";
                Toast.makeText(activity, "Order status alerts " + state, Toast.LENGTH_SHORT).show();
            });
        }

        if (switchPromos != null) {
            switchPromos.setOnCheckedChangeListener((buttonView, isChecked) -> {
                String state = isChecked ? "enabled" : "disabled";
                Toast.makeText(activity, "Promotional alerts " + state, Toast.LENGTH_SHORT).show();
            });
        }

        activity.setupBottomNav();
        activity.updateCartBadges();
    }
}