package com.example.project_appsss;

import com.example.project_appsss.R;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class user_profile_area {

    public void setupProfile(MainActivity activity) {
        activity.setContentView(R.layout.profile_area);

        TextView tvAvatarInitials = activity.findViewById(R.id.tvAvatarInitials);
        TextView tvProfileName = activity.findViewById(R.id.tvProfileName);
        TextView tvProfileEmail = activity.findViewById(R.id.tvProfileEmail);
        TextView tvProfilePhoneStatus = activity.findViewById(R.id.tvProfilePhoneStatus);
        TextView tvPhoneVerificationTag = activity.findViewById(R.id.tvPhoneVerificationTag);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        // 1. DYNAMIC FIREBASE USER DATA SYNC
        if (currentUser != null) {
            String uid = currentUser.getUid();
            String authEmail = currentUser.getEmail() != null ? currentUser.getEmail() : "";
            activity.registeredEmail = authEmail;

            DatabaseReference userRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("users").child(uid);
            userRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String name = snapshot.child("name").getValue(String.class);
                        String phone = snapshot.child("phone").getValue(String.class);
                        String address = snapshot.child("address").getValue(String.class);
                        Boolean isVerified = snapshot.child("isPhoneVerified").getValue(Boolean.class);

                        if (name != null) activity.registeredName = name;
                        if (phone != null) activity.registeredPhone = phone;
                        if (address != null) activity.selectedDeliveryAddress = address;
                        if (isVerified != null) activity.isPhoneVerified = isVerified;

                        // Update Views
                        updateProfileUI(activity, tvProfileName, tvAvatarInitials, tvProfileEmail, tvProfilePhoneStatus, tvPhoneVerificationTag);
                    } else {
                        updateProfileUI(activity, tvProfileName, tvAvatarInitials, tvProfileEmail, tvProfilePhoneStatus, tvPhoneVerificationTag);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    updateProfileUI(activity, tvProfileName, tvAvatarInitials, tvProfileEmail, tvProfilePhoneStatus, tvPhoneVerificationTag);
                }
            });
        } else {
            updateProfileUI(activity, tvProfileName, tvAvatarInitials, tvProfileEmail, tvProfilePhoneStatus, tvPhoneVerificationTag);
        }

        // Profile Settings Listener
        View btnSettings = activity.findViewById(R.id.btnSettings);
        boolean isAdmin = currentUser != null && "admin@sarifresh.ph".equalsIgnoreCase(currentUser.getEmail());
        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                if (isAdmin) {
                    activity.showAdminScreen();
                } else {
                    Toast.makeText(activity, "Settings clicked", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // EDIT PROFILE & PERMANENT ADDRESS DIALOG LISTENERS
        View btnEditProfile = activity.findViewById(R.id.btnEditProfile);
        if (btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> showEditProfileDialog(activity, tvProfileName, tvAvatarInitials));
        }

        View btnAddAddress = activity.findViewById(R.id.btnAddAddress);
        if (btnAddAddress != null) {
            btnAddAddress.setOnClickListener(v -> showEditProfileDialog(activity, tvProfileName, tvAvatarInitials));
        }

        // PHONE VERIFICATION ROW CLICK ACTION
        View btnPhoneVerificationRow = activity.findViewById(R.id.btnPhoneVerificationRow);
        if (btnPhoneVerificationRow != null) {
            btnPhoneVerificationRow.setOnClickListener(v -> {
                if (activity.isPhoneVerified) {
                    Toast.makeText(activity, "Your phone number is already verified!", Toast.LENGTH_SHORT).show();
                } else {
                    activity.showPhoneVerificationScreen();
                }
            });
        }

        View btnNotificationsRow = activity.findViewById(R.id.btnNotificationsRow);
        if (btnNotificationsRow != null) {
            btnNotificationsRow.setOnClickListener(v -> new notifications_area().setupNotifications(activity));
        }

        View btnPaymentsRow = activity.findViewById(R.id.btnPaymentsRow);
        if (btnPaymentsRow != null) {
            btnPaymentsRow.setOnClickListener(v -> new payments_area().setupPayments(activity));
        }

        View btnHelpRow = activity.findViewById(R.id.btnHelpRow);
        if (btnHelpRow != null) {
            btnHelpRow.setOnClickListener(v -> new help_support_area().setupHelpSupport(activity));
        }

        // ROUTE TO ORDER HISTORY SCREEN
        View btnOrderHistory = activity.findViewById(R.id.btnOrderHistory);
        if (btnOrderHistory != null) {
            btnOrderHistory.setOnClickListener(v -> activity.showOrderHistoryScreen());
        }

        // LOGOUT WITH FIREBASE SIGN-OUT
        View btnLogout = activity.findViewById(R.id.btnLogout);
        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                new AlertDialog.Builder(activity)
                        .setTitle("Log Out")
                        .setMessage("Are you sure you want to log out?")
                        .setPositiveButton("Log Out", (dialog, which) -> {
                            FirebaseAuth.getInstance().signOut();
                            activity.registeredName = "";
                            activity.registeredEmail = "";
                            activity.registeredPassword = "";
                            activity.registeredPhone = "";
                            activity.selectedDeliveryAddress = "";
                            activity.isPhoneVerified = false;
                            activity.showLoginScreen();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            });
        }

        activity.setupBottomNav();
        activity.updateCartBadges();
    }

    private void updateProfileUI(MainActivity activity, TextView tvProfileName, TextView tvAvatarInitials, TextView tvProfileEmail, TextView tvProfilePhoneStatus, TextView tvPhoneVerificationTag) {
        if (tvProfileName != null) {
            tvProfileName.setText(activity.registeredName.isEmpty() ? "Guest User" : activity.registeredName);
        }
        if (tvAvatarInitials != null) {
            tvAvatarInitials.setText(activity.getInitials(activity.registeredName.isEmpty() ? "Guest" : activity.registeredName));
        }
        if (tvProfileEmail != null) {
            tvProfileEmail.setText(activity.registeredEmail.isEmpty() ? "guest@sarifresh.ph" : activity.registeredEmail);
        }

        // Phone Verification Status Handling
        if (tvProfilePhoneStatus != null && tvPhoneVerificationTag != null) {
            if (activity.isPhoneVerified) {
                String last4 = (activity.registeredPhone != null && activity.registeredPhone.length() >= 4)
                        ? activity.registeredPhone.substring(activity.registeredPhone.length() - 4)
                        : "0142";
                tvProfilePhoneStatus.setText("✓ Phone verified · *** " + last4);
                tvProfilePhoneStatus.setTextColor(Color.parseColor("#8EB89B"));

                tvPhoneVerificationTag.setText("VERIFIED");
                tvPhoneVerificationTag.setTextColor(Color.parseColor("#2A4836"));
                tvPhoneVerificationTag.setBackgroundColor(Color.parseColor("#E2EFE0"));
            } else {
                tvProfilePhoneStatus.setText("✕ Phone not verified");
                tvProfilePhoneStatus.setTextColor(Color.parseColor("#FF5252"));

                tvPhoneVerificationTag.setText("NOT VERIFIED");
                tvPhoneVerificationTag.setTextColor(Color.parseColor("#D32F2F"));
                tvPhoneVerificationTag.setBackgroundColor(Color.parseColor("#FFEBEE"));
            }
        }
    }

    private void showEditProfileDialog(MainActivity activity, TextView tvProfileName, TextView tvAvatarInitials) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        Context context = activity;

        LinearLayout rootLayout = new LinearLayout(context);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setPadding(48, 48, 48, 36);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(32f);
        rootLayout.setBackground(cardBg);

        // Header Title
        TextView tvTitle = new TextView(context);
        tvTitle.setText("Edit Profile & Address");
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(Color.parseColor("#1A1A1A"));
        tvTitle.setPadding(0, 0, 0, 24);
        rootLayout.addView(tvTitle);

        ScrollView scrollView = new ScrollView(context);
        LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.VERTICAL);

        // --- PERSONAL DETAILS SECTION ---
        TextView tvNameHeader = new TextView(context);
        tvNameHeader.setText("PERSONAL DETAILS");
        tvNameHeader.setTextSize(11);
        tvNameHeader.setTypeface(null, Typeface.BOLD);
        tvNameHeader.setTextColor(Color.parseColor("#2A4836"));
        tvNameHeader.setPadding(0, 0, 0, 12);
        container.addView(tvNameHeader);

        EditText etFirstName = createStyledEditText(context, "First Name", InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText etMiddleName = createStyledEditText(context, "Middle Name (Optional)", InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText etLastName = createStyledEditText(context, "Surname / Last Name", InputType.TYPE_TEXT_FLAG_CAP_WORDS);

        if (activity.registeredName != null && !activity.registeredName.trim().isEmpty()) {
            String[] nameParts = activity.registeredName.trim().split("\\s+");
            if (nameParts.length == 1) {
                etFirstName.setText(nameParts[0]);
            } else if (nameParts.length == 2) {
                etFirstName.setText(nameParts[0]);
                etLastName.setText(nameParts[1]);
            } else if (nameParts.length >= 3) {
                etFirstName.setText(nameParts[0]);
                etMiddleName.setText(nameParts[1]);
                StringBuilder sb = new StringBuilder();
                for (int i = 2; i < nameParts.length; i++) {
                    sb.append(nameParts[i]).append(i == nameParts.length - 1 ? "" : " ");
                }
                etLastName.setText(sb.toString());
            }
        }

        container.addView(etFirstName);
        container.addView(etMiddleName);
        container.addView(etLastName);

        // --- PERMANENT ADDRESS SECTION ---
        TextView tvAddressHeader = new TextView(context);
        tvAddressHeader.setText("PERMANENT ADDRESS");
        tvAddressHeader.setTextSize(11);
        tvAddressHeader.setTypeface(null, Typeface.BOLD);
        tvAddressHeader.setTextColor(Color.parseColor("#2A4836"));
        tvAddressHeader.setPadding(0, 20, 0, 12);
        container.addView(tvAddressHeader);

        EditText etBarangay = createStyledEditText(context, "Barangay (e.g., Buhangin / Communal)", InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText etSubdivision = createStyledEditText(context, "Subdivision / Village (Optional)", InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText etStreetBlockLot = createStyledEditText(context, "Street, Block & Lot No.", InputType.TYPE_TEXT_FLAG_CAP_WORDS);

        container.addView(etBarangay);
        container.addView(etSubdivision);
        container.addView(etStreetBlockLot);

        scrollView.addView(container);
        rootLayout.addView(scrollView);

        // Action Buttons Layout
        LinearLayout buttonRow = new LinearLayout(context);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setGravity(Gravity.END);
        buttonRow.setPadding(0, 24, 0, 0);

        TextView btnCancel = new TextView(context);
        btnCancel.setText("Cancel");
        btnCancel.setTextSize(15);
        btnCancel.setTextColor(Color.parseColor("#757575"));
        btnCancel.setPadding(24, 16, 24, 16);

        TextView btnSave = new TextView(context);
        btnSave.setText("Save Details");
        btnSave.setTextSize(15);
        btnSave.setTypeface(null, Typeface.BOLD);
        btnSave.setTextColor(Color.parseColor("#2A4836"));
        btnSave.setPadding(24, 16, 0, 16);

        buttonRow.addView(btnCancel);
        buttonRow.addView(btnSave);
        rootLayout.addView(buttonRow);

        builder.setView(rootLayout);
        AlertDialog dialog = builder.create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String firstName = etFirstName.getText().toString().trim();
            String middleName = etMiddleName.getText().toString().trim();
            String lastName = etLastName.getText().toString().trim();

            String barangay = etBarangay.getText().toString().trim();
            String subdivision = etSubdivision.getText().toString().trim();
            String streetBlockLot = etStreetBlockLot.getText().toString().trim();

            if (firstName.isEmpty() || lastName.isEmpty()) {
                Toast.makeText(activity, "First Name and Surname are required!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (barangay.isEmpty() || streetBlockLot.isEmpty()) {
                Toast.makeText(activity, "Barangay and Street/Block/Lot are required!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Construct Full Name
            StringBuilder fullNameBuilder = new StringBuilder(firstName);
            if (!middleName.isEmpty()) {
                fullNameBuilder.append(" ").append(middleName);
            }
            fullNameBuilder.append(" ").append(lastName);
            String fullRegisteredName = fullNameBuilder.toString();

            // Construct Permanent Delivery Address
            StringBuilder addressBuilder = new StringBuilder();
            addressBuilder.append(streetBlockLot);

            if (!subdivision.isEmpty()) {
                addressBuilder.append(", ").append(subdivision);
            }

            if (!barangay.toLowerCase().startsWith("brgy") && !barangay.toLowerCase().startsWith("barangay")) {
                addressBuilder.append(", Brgy. ").append(barangay);
            } else {
                addressBuilder.append(", ").append(barangay);
            }

            addressBuilder.append(", Davao City");
            String fullAddress = addressBuilder.toString();

            // Save globally to MainActivity
            activity.registeredName = fullRegisteredName;
            activity.selectedDeliveryAddress = fullAddress;

            // Sync Update to Firebase Realtime Database
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                DatabaseReference userRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("users").child(user.getUid());
                userRef.child("name").setValue(fullRegisteredName);
                userRef.child("address").setValue(fullAddress);
            }

            // Update Profile UI Views
            if (tvProfileName != null) tvProfileName.setText(fullRegisteredName);
            if (tvAvatarInitials != null) tvAvatarInitials.setText(activity.getInitials(fullRegisteredName));

            Toast.makeText(activity, "Profile & Address updated successfully!", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    private EditText createStyledEditText(Context context, String hint, int inputType) {
        EditText editText = new EditText(context);
        editText.setHint(hint);
        editText.setInputType(inputType);
        editText.setTextSize(14f);
        editText.setTextColor(Color.parseColor("#1A1A1A"));
        editText.setHintTextColor(Color.parseColor("#888888"));
        editText.setPadding(12, 16, 12, 16);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 16);
        editText.setLayoutParams(params);

        return editText;
    }
}