package com.example.project_appsss;

import com.example.project_appsss.R;

import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class oder_area {

    public void setupOrder(MainActivity activity) {
        activity.setContentView(R.layout.order_area);

        LinearLayout llCartItemsContainer = activity.findViewById(R.id.llCartItemsContainer);
        TextView tvOrderTotalPrice = activity.findViewById(R.id.tvOrderTotalPrice);
        TextView tvTotalItemsCount = activity.findViewById(R.id.tvTotalItemsCount);
        TextView tvDeliveryFeeNote = activity.findViewById(R.id.tvDeliveryFeeNote);
        EditText etCustomerName = activity.findViewById(R.id.etCustomerName);
        EditText etContactNumber = activity.findViewById(R.id.etContactNumber);
        EditText etDeliveryAddress = activity.findViewById(R.id.etDeliveryAddress);
        EditText etSpecialInstructions = activity.findViewById(R.id.etSpecialInstructions);

        // Payment Method UI Components
        RadioGroup rgPaymentMethod = activity.findViewById(R.id.rgPaymentMethod);
        RadioButton rbCashless = activity.findViewById(R.id.rbCashless);
        LinearLayout llGCashInfo = activity.findViewById(R.id.llGCashInfo);

        View btnSubmitOrder = activity.findViewById(R.id.btnSubmitOrder);
        View btnBackFromOrder = activity.findViewById(R.id.btnBackFromOrder);

        // Pre-fill Customer Name & Phone if registered
        if (etCustomerName != null && !activity.registeredName.isEmpty()) {
            etCustomerName.setText(activity.registeredName);
        }
        if (etContactNumber != null && !activity.registeredPhone.isEmpty()) {
            etContactNumber.setText(activity.registeredPhone);
        }

        // ====================================================
        // PAYMENT METHOD SELECTION (TOGGLE GCASH DETAILS BOX)
        // ====================================================
        if (rgPaymentMethod != null && llGCashInfo != null) {
            rgPaymentMethod.setOnCheckedChangeListener((group, checkedId) -> {
                if (checkedId == R.id.rbCashless) {
                    llGCashInfo.setVisibility(View.VISIBLE);
                } else {
                    llGCashInfo.setVisibility(View.GONE);
                }
            });
        }

        // ====================================================
        // STANDARD DELIVERY ADDRESS INPUT
        // ====================================================
        if (etDeliveryAddress != null) {
            if (!activity.selectedDeliveryAddress.isEmpty() && etDeliveryAddress.getText().toString().trim().isEmpty()) {
                etDeliveryAddress.setText(activity.selectedDeliveryAddress);
            }

            // Enable typing directly into the text box
            etDeliveryAddress.setFocusable(true);
            etDeliveryAddress.setFocusableInTouchMode(true);
            etDeliveryAddress.setClickable(true);
            etDeliveryAddress.setOnClickListener(null);
        }

        // ====================================================
        // POPULATE ITEMS & ENABLE REMOVE ITEM DIALOG
        // ====================================================
        if (llCartItemsContainer != null) {
            llCartItemsContainer.removeAllViews();

            if (activity.cartList.isEmpty()) {
                TextView tvEmpty = new TextView(activity);
                tvEmpty.setText("Your cart is empty.");
                tvEmpty.setTextColor(Color.GRAY);
                tvEmpty.setPadding(0, 24, 0, 24);
                llCartItemsContainer.addView(tvEmpty);

                if (tvOrderTotalPrice != null) tvOrderTotalPrice.setText("₱0");
                if (tvTotalItemsCount != null) tvTotalItemsCount.setText("TOTAL · 0 ITEMS");
                if (tvDeliveryFeeNote != null) tvDeliveryFeeNote.setText("incl. ₱49 delivery");
            } else {
                double subtotal = 0;
                int totalCount = 0;

                for (MainActivity.CartItem item : activity.cartList) {
                    subtotal += item.getTotalPrice();
                    totalCount += item.quantity;

                    // Row layout container
                    LinearLayout itemRow = new LinearLayout(activity);
                    itemRow.setOrientation(LinearLayout.HORIZONTAL);
                    itemRow.setPadding(0, 16, 0, 16);
                    itemRow.setGravity(Gravity.CENTER_VERTICAL);

                    // Item Name
                    TextView tvName = new TextView(activity);
                    tvName.setText(item.itemName);
                    tvName.setTextSize(14);
                    tvName.setTextColor(Color.parseColor("#1A1A1A"));
                    LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                    tvName.setLayoutParams(nameParams);

                    // Quantity + Unit + Total Price
                    TextView tvDetails = new TextView(activity);
                    tvDetails.setText(item.quantity + " " + item.unitLabel + " · ₱" + (int) item.getTotalPrice());
                    tvDetails.setTextSize(13);
                    tvDetails.setTextColor(Color.parseColor("#666666"));

                    // Red "✕" Delete Button
                    TextView btnRemove = new TextView(activity);
                    btnRemove.setText("  ✕ ");
                    btnRemove.setTextSize(16);
                    btnRemove.setTextColor(Color.parseColor("#D32F2F"));
                    btnRemove.setPadding(16, 8, 8, 8);

                    // Click listener to remove item from cart
                    View.OnClickListener removeListener = v -> {
                        new AlertDialog.Builder(activity)
                                .setTitle("Remove Item")
                                .setMessage("Do you want to remove \"" + item.itemName + "\" from your order?")
                                .setPositiveButton("Remove", (dialog, which) -> {
                                    activity.cartList.remove(item);
                                    Toast.makeText(activity, item.itemName + " removed", Toast.LENGTH_SHORT).show();
                                    activity.updateCartBadges();
                                    setupOrder(activity); // Refresh order screen
                                })
                                .setNegativeButton("Cancel", null)
                                .show();
                    };

                    btnRemove.setOnClickListener(removeListener);
                    itemRow.setOnClickListener(removeListener);

                    itemRow.addView(tvName);
                    itemRow.addView(tvDetails);
                    itemRow.addView(btnRemove);

                    llCartItemsContainer.addView(itemRow);
                }

                // ====================================================
                // FREE DELIVERY FEATURE (SUBTOTAL >= ₱800 -> ₱0 FEE)
                // ====================================================
                int deliveryFee = (subtotal >= 800) ? 0 : 49;
                int grandTotal = (int) (subtotal + deliveryFee);

                if (tvOrderTotalPrice != null) {
                    tvOrderTotalPrice.setText("₱" + grandTotal);
                }
                if (tvTotalItemsCount != null) {
                    tvTotalItemsCount.setText("TOTAL · " + totalCount + " ITEMS");
                }
                if (tvDeliveryFeeNote != null) {
                    if (deliveryFee == 0) {
                        tvDeliveryFeeNote.setText("FREE delivery applied!");
                        tvDeliveryFeeNote.setTextColor(Color.parseColor("#2A4836"));
                    } else {
                        tvDeliveryFeeNote.setText("incl. ₱49 delivery (Free on ₱800+)");
                    }
                }
            }
        }

        // ====================================================
        // BACK BUTTON LOGIC
        // ====================================================
        if (btnBackFromOrder != null) {
            btnBackFromOrder.setOnClickListener(v -> activity.showHomeScreen());
        }

        // ====================================================
        // SUBMIT ORDER BUTTON LOGIC (FIREBASE INTEGRATED)
        // ====================================================
        if (btnSubmitOrder != null) {
            btnSubmitOrder.setOnClickListener(v -> {
                if (activity.cartList.isEmpty()) {
                    Toast.makeText(activity, "Your cart is empty! Please add items first.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (etDeliveryAddress != null && etDeliveryAddress.getText().toString().trim().isEmpty()) {
                    Toast.makeText(activity, "Please enter a delivery address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // CHECK PHONE VERIFICATION STATUS
                if (!activity.isPhoneVerified) {
                    new AlertDialog.Builder(activity)
                            .setTitle("Account Not Verified")
                            .setMessage("Your account is currently UNVERIFIED. You must verify your phone number first to complete and send orders to the admin queue.\n\nWould you like to verify now?")
                            .setPositiveButton("Verify Now", (dialog, which) -> activity.showPhoneVerificationScreen())
                            .setNegativeButton("Cancel", null)
                            .show();
                    return;
                }

                // Determine Selected Payment Method
                String paymentMethod = (rbCashless != null && rbCashless.isChecked()) ? "GCash (Cashless)" : "Cash on Delivery";

                // Calculate Subtotal + Delivery Fee (Waived if >= ₱800)
                double subtotal = 0;
                for (MainActivity.CartItem item : activity.cartList) {
                    subtotal += item.getTotalPrice();
                }

                int deliveryFee = (subtotal >= 800) ? 0 : 49;
                int grandTotal = (int) (subtotal + deliveryFee);

                // Gather Customer Information
                String customerName = (etCustomerName != null && !etCustomerName.getText().toString().trim().isEmpty())
                        ? etCustomerName.getText().toString().trim() : (activity.registeredName.isEmpty() ? "Customer" : activity.registeredName);
                String contactNumber = (etContactNumber != null && !etContactNumber.getText().toString().trim().isEmpty())
                        ? etContactNumber.getText().toString().trim() : activity.registeredPhone;
                String deliveryAddress = (etDeliveryAddress != null) ? etDeliveryAddress.getText().toString().trim() : activity.selectedDeliveryAddress;
                String specialInstructions = (etSpecialInstructions != null && !etSpecialInstructions.getText().toString().trim().isEmpty())
                        ? etSpecialInstructions.getText().toString().trim() : "None";

                // Create Order Model
                MainActivity.CustomerOrder newOrder = new MainActivity.CustomerOrder(
                        customerName,
                        contactNumber,
                        deliveryAddress,
                        specialInstructions,
                        activity.cartList,
                        grandTotal,
                        activity.isPhoneVerified,
                        paymentMethod
                );

                // Push Order to Firebase Realtime Database (/orders)
                DatabaseReference ordersRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("orders");
                String orderKey = ordersRef.push().getKey();

                if (orderKey != null) {
                    newOrder.orderId = orderKey;
                    ordersRef.child(orderKey).setValue(newOrder)
                            .addOnSuccessListener(aVoid -> {
                                activity.adminOrderQueue.add(newOrder); // Keep local list updated
                                String deliveryMsg = (deliveryFee == 0) ? "\nDelivery: FREE (Order ₱800+ Promo)" : "\nDelivery: ₱49";

                                new AlertDialog.Builder(activity)
                                        .setTitle("Order Submitted!")
                                        .setMessage("Payment: " + paymentMethod + deliveryMsg + "\n\nYour order has been submitted to the admin queue. You will receive confirmation shortly.")
                                        .setPositiveButton("OK", (dialog, which) -> {
                                            activity.cartList.clear();
                                            activity.updateCartBadges();
                                            activity.showHomeScreen();
                                        })
                                        .setCancelable(false)
                                        .show();
                            })
                            .addOnFailureListener(e -> Toast.makeText(activity, "Failed to submit order: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            });
        }

        activity.setupBottomNav();
        activity.updateCartBadges();
    }
}