package com.example.project_appsss;

import com.example.project_appsss.R;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class payments_area {

    public void setupPayments(MainActivity activity) {
        activity.setContentView(R.layout.payments_area);

        View btnBackFromPayments = activity.findViewById(R.id.btnBackFromPayments);
        TextView btnCopyGCash = activity.findViewById(R.id.btnCopyGCash);

        // ====================================================
        // BACK BUTTON LOGIC (NAVIGATES BACK TO PROFILE)
        // ====================================================
        if (btnBackFromPayments != null) {
            btnBackFromPayments.setOnClickListener(v -> new user_profile_area().setupProfile(activity));
        }

        // ====================================================
        // COPY GCASH NUMBER TO CLIPBOARD
        // ====================================================
        if (btnCopyGCash != null) {
            btnCopyGCash.setOnClickListener(v -> {
                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("GCash Number", "09178889999");
                if (clipboard != null) {
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(activity, "GCash number copied to clipboard!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        activity.setupBottomNav();
        activity.updateCartBadges();
    }
}
