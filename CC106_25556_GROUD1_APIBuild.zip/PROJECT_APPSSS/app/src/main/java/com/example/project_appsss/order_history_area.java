package com.example.project_appsss;

import com.example.project_appsss.R;

import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class order_history_area {

    public void setupHistory(MainActivity activity) {
        activity.setContentView(R.layout.order_history_area);

        ImageView btnBackFromHistory = activity.findViewById(R.id.btnBackFromHistory);
        TextView tvHistoryUserName = activity.findViewById(R.id.tvHistoryUserName);
        LinearLayout containerOrderHistoryList = activity.findViewById(R.id.containerOrderHistoryList);

        // Bind Customer Name dynamically
        if (tvHistoryUserName != null) {
            String customerName = activity.registeredName.isEmpty() ? "GUEST USER" : activity.registeredName;
            tvHistoryUserName.setText(customerName.toUpperCase());
        }

        if (btnBackFromHistory != null) {
            btnBackFromHistory.setOnClickListener(v -> activity.showProfileScreen());
        }

        // Fetch Live Order History from Firebase
        if (containerOrderHistoryList != null) {
            loadOrderHistoryFromFirebase(activity, containerOrderHistoryList);
        }

        activity.setupBottomNav();
    }

    private void loadOrderHistoryFromFirebase(MainActivity activity, LinearLayout container) {
        DatabaseReference ordersRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("orders");

        ordersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                container.removeAllViews();

                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    showEmptyHistory(activity, container);
                    return;
                }

                int orderCounter = 1001;
                boolean userHasOrders = false;

                for (DataSnapshot orderSnap : snapshot.getChildren()) {
                    MainActivity.CustomerOrder order = orderSnap.getValue(MainActivity.CustomerOrder.class);

                    if (order != null) {
                        order.orderId = orderSnap.getKey();

                        // Match orders to the logged-in customer (by Name or Phone)
                        boolean matchesUser = activity.registeredName.isEmpty()
                                || (order.customerName != null && order.customerName.equalsIgnoreCase(activity.registeredName))
                                || (order.contactNumber != null && !activity.registeredPhone.isEmpty() && order.contactNumber.equals(activity.registeredPhone));

                        if (matchesUser) {
                            userHasOrders = true;

                            CardView card = new CardView(activity);
                            CardView.LayoutParams cardParams = new CardView.LayoutParams(
                                    CardView.LayoutParams.MATCH_PARENT, CardView.LayoutParams.WRAP_CONTENT);
                            cardParams.setMargins(0, 0, 0, 24);
                            card.setLayoutParams(cardParams);
                            card.setRadius(16);
                            card.setCardBackgroundColor(Color.WHITE);
                            card.setCardElevation(3);

                            LinearLayout cardLayout = new LinearLayout(activity);
                            cardLayout.setOrientation(LinearLayout.VERTICAL);
                            cardLayout.setPadding(24, 24, 24, 24);

                            // Top Row: Order Header & Status Badge
                            LinearLayout topRow = new LinearLayout(activity);
                            topRow.setOrientation(LinearLayout.HORIZONTAL);

                            TextView tvOrderTitle = new TextView(activity);
                            tvOrderTitle.setText("Order #" + orderCounter);
                            tvOrderTitle.setTextSize(16);
                            tvOrderTitle.setTypeface(null, Typeface.BOLD);
                            tvOrderTitle.setTextColor(Color.parseColor("#1A1A1A"));
                            LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                            tvOrderTitle.setLayoutParams(titleParams);

                            TextView tvStatusBadge = new TextView(activity);
                            tvStatusBadge.setTextSize(11);
                            tvStatusBadge.setTypeface(null, Typeface.BOLD);
                            tvStatusBadge.setPadding(16, 8, 16, 8);

                            if ("ACCEPTED".equalsIgnoreCase(order.status)) {
                                tvStatusBadge.setText("✓ CONFIRMED BY ADMIN");
                                tvStatusBadge.setTextColor(Color.parseColor("#2E7D32"));
                                tvStatusBadge.setBackgroundColor(Color.parseColor("#E8F5E9"));
                            } else if ("REJECTED".equalsIgnoreCase(order.status)) {
                                tvStatusBadge.setText("✕ REJECTED");
                                tvStatusBadge.setTextColor(Color.parseColor("#D32F2F"));
                                tvStatusBadge.setBackgroundColor(Color.parseColor("#FFEBEE"));
                            } else {
                                tvStatusBadge.setText("⏳ AWAITING REVIEW");
                                tvStatusBadge.setTextColor(Color.parseColor("#E65100"));
                                tvStatusBadge.setBackgroundColor(Color.parseColor("#FFF3E0"));
                            }

                            topRow.addView(tvOrderTitle);
                            topRow.addView(tvStatusBadge);

                            // Delivery Address
                            TextView tvAddress = new TextView(activity);
                            String addrStr = (order.deliveryAddress != null && !order.deliveryAddress.isEmpty()) ? order.deliveryAddress : "Selected on Map";
                            tvAddress.setText("Delivery Address: " + addrStr);
                            tvAddress.setTextSize(13);
                            tvAddress.setTextColor(Color.parseColor("#666666"));
                            tvAddress.setPadding(0, 12, 0, 4);

                            // Payment Method
                            TextView tvPayment = new TextView(activity);
                            String paymentStr = (order.paymentMethod != null && !order.paymentMethod.isEmpty()) ? order.paymentMethod : "Cash on Delivery";
                            tvPayment.setText("Payment Method: " + paymentStr);
                            tvPayment.setTextSize(13);
                            tvPayment.setTypeface(null, Typeface.BOLD);
                            tvPayment.setTextColor(Color.parseColor("#2A4836"));
                            tvPayment.setPadding(0, 0, 0, 12);

                            // Items Breakdown
                            StringBuilder itemsSummary = new StringBuilder("Items Purchased:\n");
                            if (order.items != null) {
                                for (MainActivity.CartItem item : order.items) {
                                    itemsSummary.append("• ").append(item.itemName)
                                            .append(" (x").append(item.quantity).append(" ")
                                            .append(item.unitLabel).append(") - ₱")
                                            .append((int) item.getTotalPrice()).append("\n");
                                }
                            }

                            TextView tvItems = new TextView(activity);
                            tvItems.setText(itemsSummary.toString().trim());
                            tvItems.setTextSize(13);
                            tvItems.setTextColor(Color.parseColor("#333333"));

                            // Grand Total
                            TextView tvTotal = new TextView(activity);
                            tvTotal.setText("Total Paid: ₱" + order.totalAmount);
                            tvTotal.setTextSize(15);
                            tvTotal.setTypeface(null, Typeface.BOLD);
                            tvTotal.setTextColor(Color.parseColor("#2A4836"));
                            tvTotal.setPadding(0, 12, 0, 0);

                            cardLayout.addView(topRow);
                            cardLayout.addView(tvAddress);
                            cardLayout.addView(tvPayment);
                            cardLayout.addView(tvItems);
                            cardLayout.addView(tvTotal);

                            card.addView(cardLayout);
                            container.addView(card);
                        }
                    }
                    orderCounter++;
                }

                if (!userHasOrders) {
                    showEmptyHistory(activity, container);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(activity, "Failed to load order history: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showEmptyHistory(MainActivity activity, LinearLayout container) {
        TextView tvEmpty = new TextView(activity);
        tvEmpty.setText("No previous orders found.\nPlace an order to see its history!");
        tvEmpty.setTextColor(Color.GRAY);
        tvEmpty.setTextSize(14);
        tvEmpty.setPadding(0, 48, 0, 0);
        tvEmpty.setGravity(android.view.Gravity.CENTER);
        container.addView(tvEmpty);
    }
}