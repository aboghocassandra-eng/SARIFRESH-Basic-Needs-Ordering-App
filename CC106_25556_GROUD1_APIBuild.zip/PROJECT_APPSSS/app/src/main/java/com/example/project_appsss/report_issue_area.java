package com.example.project_appsss;

import com.example.project_appsss.R;

import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class report_issue_area {

    public void setupReportIssue(MainActivity activity) {
        activity.setContentView(R.layout.report_issue_area);

        View btnBackFromReportIssue = activity.findViewById(R.id.btnBackFromReportIssue);
        RadioGroup rgIssueType = activity.findViewById(R.id.rgIssueType);
        EditText etOrderReference = activity.findViewById(R.id.etOrderReference);
        EditText etIssueDescription = activity.findViewById(R.id.etIssueDescription);
        View btnSubmitReport = activity.findViewById(R.id.btnSubmitReport);

        // BACK BUTTON LOGIC (NAVIGATES BACK TO HELP & SUPPORT)
        if (btnBackFromReportIssue != null) {
            btnBackFromReportIssue.setOnClickListener(v -> new help_support_area().setupHelpSupport(activity));
        }

        // SUBMIT REPORT ACTION (FIREBASE INTEGRATION)
        if (btnSubmitReport != null) {
            btnSubmitReport.setOnClickListener(v -> {
                String description = etIssueDescription != null ? etIssueDescription.getText().toString().trim() : "";

                if (description.isEmpty()) {
                    if (etIssueDescription != null) {
                        etIssueDescription.setError("Please describe the issue before submitting.");
                        etIssueDescription.requestFocus();
                    }
                    Toast.makeText(activity, "Please describe the issue before submitting.", Toast.LENGTH_SHORT).show();
                    return;
                }

                String selectedCategory = "Other Inquiry or Feedback";
                if (rgIssueType != null) {
                    int selectedId = rgIssueType.getCheckedRadioButtonId();
                    RadioButton selectedRadio = activity.findViewById(selectedId);
                    if (selectedRadio != null) {
                        selectedCategory = selectedRadio.getText().toString();
                    }
                }

                String orderRef = (etOrderReference != null) ? etOrderReference.getText().toString().trim() : "";

                // Push report record to Firebase Realtime Database
                DatabaseReference reportsRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("reports");
                String reportId = reportsRef.push().getKey();

                if (reportId != null) {
                    Map<String, Object> reportData = new HashMap<>();
                    reportData.put("reportId", reportId);
                    reportData.put("user", (activity.registeredName != null && !activity.registeredName.isEmpty())
                            ? activity.registeredName : "Customer");
                    reportData.put("issueType", selectedCategory);
                    reportData.put("orderRef", orderRef.isEmpty() ? "None" : orderRef);
                    reportData.put("description", description);
                    reportData.put("timestamp", System.currentTimeMillis());

                    String finalCategory = selectedCategory;
                    reportsRef.child(reportId).setValue(reportData)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(activity, "Report submitted! Our team will review your " + finalCategory.toLowerCase() + ".", Toast.LENGTH_LONG).show();
                                new help_support_area().setupHelpSupport(activity);
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(activity, "Failed to submit report: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            });
        }

        activity.setupBottomNav();
        activity.updateCartBadges();
    }
}