package com.example.project_appsss;

import android.content.Context;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.XYTileSource;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MapManager {

    // STORE LOCATION: Communal, Buhangin, Davao City
    private static final double STORE_LAT = 7.138059;
    private static final double STORE_LNG = 125.639824;
    private static final GeoPoint STORE_LOCATION = new GeoPoint(STORE_LAT, STORE_LNG);

    // MapTiler API Key
    private static final String MAPTILER_API_KEY = "KEh8jMoQMIVrR81vn7On";

    // MapTiler Tile Engine Configuration
    public static final OnlineTileSourceBase MAPTILER_TILES = new XYTileSource(
            "MapTiler_Streets_v1",
            0, 19, 256, ".png?key=" + MAPTILER_API_KEY,
            new String[]{
                    "https://api.maptiler.com/maps/streets-v2/256/"
            }
    );

    public MapView mMapView;
    private Marker storeMarker;
    private Marker deliveryMarker;
    private Polyline routeLine;
    private MainActivity mainActivity;

    public void setupMap(MainActivity activity) {
        this.mainActivity = activity;

        try {
            Context context = activity.getApplicationContext();

            // Clear old cache folder to discard previous 403 blocked tile files
            File freshCacheDir = new File(context.getCacheDir(), "maptiler_cache_v2");
            Configuration.getInstance().setOsmdroidBasePath(freshCacheDir);
            Configuration.getInstance().setOsmdroidTileCache(new File(freshCacheDir, "tiles"));

            Configuration.getInstance().setUserAgentValue("SariFreshDavaoDeliveryApp_v1_0");
            Configuration.getInstance().load(context, context.getSharedPreferences("osmdroid_pref", Context.MODE_PRIVATE));

            // Bind MapView
            View view = activity.findViewById(R.id.mapView);
            if (view instanceof MapView) {
                mMapView = (MapView) view;
            } else {
                Toast.makeText(activity, "XML mismatch: Update map_order_area.xml", Toast.LENGTH_LONG).show();
                return;
            }

            // Apply MapTiler tile provider
            mMapView.setTileSource(MAPTILER_TILES);
            mMapView.setMultiTouchControls(true);
            mMapView.getController().setZoom(15.0);
            mMapView.getController().setCenter(STORE_LOCATION);

            mMapView.getOverlays().clear();

            // Map Tap Receiver
            MapEventsReceiver receiver = new MapEventsReceiver() {
                @Override
                public boolean singleTapConfirmedHelper(GeoPoint p) {
                    if (mMapView != null) {
                        mMapView.post(() -> updateDeliveryPin(p, null));
                    }
                    return true;
                }

                @Override
                public boolean longPressHelper(GeoPoint p) {
                    return false;
                }
            };
            MapEventsOverlay eventsOverlay = new MapEventsOverlay(receiver);
            mMapView.getOverlays().add(eventsOverlay);

            // Store Location Marker
            storeMarker = new Marker(mMapView);
            storeMarker.setPosition(STORE_LOCATION);
            storeMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            storeMarker.setTitle("SariFresh Communal Main");
            storeMarker.setSnippet("Communal, Buhangin, Davao City");
            mMapView.getOverlays().add(storeMarker);

            // Customer Delivery Pin
            deliveryMarker = new Marker(mMapView);
            deliveryMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            deliveryMarker.setTitle("Delivery Location");
            deliveryMarker.setVisible(false);
            mMapView.getOverlays().add(deliveryMarker);

            // Route Polyline
            routeLine = new Polyline();
            routeLine.setColor(Color.parseColor("#2A4836"));
            routeLine.setWidth(10.0f);
            routeLine.setVisible(false);
            mMapView.getOverlays().add(routeLine);

            mMapView.onResume();

            // Button: Recenter Map
            View btnRecenterMap = activity.findViewById(R.id.btnRecenterMap);
            if (btnRecenterMap != null) {
                btnRecenterMap.setOnClickListener(v -> {
                    if (mMapView != null) {
                        mMapView.getController().animateTo(STORE_LOCATION);
                        mMapView.getController().setZoom(15.0);
                        Toast.makeText(activity, "Centered on Communal Store", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            // Button: Use My Location
            View btnUseMyLocation = activity.findViewById(R.id.btnUseMyLocation);
            if (btnUseMyLocation != null) {
                btnUseMyLocation.setOnClickListener(v -> {
                    GeoPoint defaultDeliveryLoc = new GeoPoint(7.141200, 125.642100);
                    if (mMapView != null) {
                        mMapView.getController().animateTo(defaultDeliveryLoc);
                        mMapView.post(() -> updateDeliveryPin(defaultDeliveryLoc, "Current Location (Buhangin)"));
                    }
                });
            }

            // Restore saved location pin if selected
            if (mainActivity.selectedDeliveryAddress != null && !mainActivity.selectedDeliveryAddress.isEmpty()) {
                GeoPoint initialPoint = new GeoPoint(STORE_LAT + 0.015, STORE_LNG + 0.012);
                if (mMapView != null) {
                    mMapView.post(() -> updateDeliveryPin(initialPoint, mainActivity.selectedDeliveryAddress));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateDeliveryPin(GeoPoint pinLocation, String customName) {
        if (mMapView == null || mainActivity == null || pinLocation == null) return;

        try {
            if (deliveryMarker != null) {
                deliveryMarker.setPosition(pinLocation);
                String addressString = (customName != null && !customName.isEmpty()) ? customName : getAddressFromGeoPoint(pinLocation);
                deliveryMarker.setSnippet(addressString);
                deliveryMarker.setVisible(true);
                deliveryMarker.showInfoWindow();

                mainActivity.selectedDeliveryAddress = addressString;
            }

            if (routeLine != null) {
                List<GeoPoint> points = new ArrayList<>();
                points.add(STORE_LOCATION);
                points.add(pinLocation);
                routeLine.setPoints(points);
                routeLine.setVisible(true);
            }

            mMapView.invalidate();

            float[] results = new float[1];
            Location.distanceBetween(STORE_LAT, STORE_LNG, pinLocation.getLatitude(), pinLocation.getLongitude(), results);
            float distanceInKm = results[0] / 1000f;

            int minEstTime = 15 + (int) (distanceInKm * 4);
            int maxEstTime = minEstTime + 15;
            String estTimeString = minEstTime + "–" + maxEstTime + " min";

            int deliveryFee = 49;
            if (distanceInKm > 5.0) {
                double extraDistance = distanceInKm - 5.0;
                int extraUnits = (int) Math.ceil(extraDistance / 2.0);
                deliveryFee += (extraUnits * 10);
            }

            TextView tvEstDelivery = mainActivity.findViewById(R.id.tvEstDelivery);
            TextView tvServiceArea = mainActivity.findViewById(R.id.tvServiceArea);
            TextView tvDeliveryFee = mainActivity.findViewById(R.id.tvDeliveryFee);

            if (tvEstDelivery != null) tvEstDelivery.setText(estTimeString);
            if (tvServiceArea != null) tvServiceArea.setText(String.format(Locale.US, "%.1f km", distanceInKm));
            if (tvDeliveryFee != null) tvDeliveryFee.setText("₱" + deliveryFee);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getAddressFromGeoPoint(GeoPoint geoPoint) {
        try {
            Geocoder geocoder = new Geocoder(mainActivity, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(geoPoint.getLatitude(), geoPoint.getLongitude(), 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address addr = addresses.get(0);
                String feature = addr.getThoroughfare() != null ? addr.getThoroughfare() : addr.getSubLocality();
                String locality = addr.getLocality() != null ? addr.getLocality() : "Davao City";
                if (feature != null) {
                    return feature + ", " + locality;
                }
                return addr.getAddressLine(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return String.format(Locale.US, "Lat: %.4f, Lng: %.4f (Davao)", geoPoint.getLatitude(), geoPoint.getLongitude());
    }

    public void onResume() {
        if (mMapView != null) mMapView.onResume();
    }

    public void onPause() {
        if (mMapView != null) mMapView.onPause();
    }

    public void onDestroy() {
        if (mMapView != null) mMapView.onDetach();
    }
}