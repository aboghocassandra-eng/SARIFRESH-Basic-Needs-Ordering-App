package com.example.project_appsss;

import com.example.project_appsss.R;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class help_support_area {

    public void setupHelpSupport(MainActivity activity) {
        activity.setContentView(R.layout.help_support_area);

        View btnBackFromHelp = activity.findViewById(R.id.btnBackFromHelp);
        View btnCallAdmin = activity.findViewById(R.id.btnCallAdmin);
        View btnReportIssue = activity.findViewById(R.id.btnReportIssue);

        // BACK BUTTON LOGIC (NAVIGATES BACK TO PROFILE)
        if (btnBackFromHelp != null) {
            btnBackFromHelp.setOnClickListener(v -> new user_profile_area().setupProfile(activity));
        }

        // STORE HOTLINE DIALER (0992-201-4615)
        if (btnCallAdmin != null) {
            btnCallAdmin.setOnClickListener(v -> {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:09922014615"));
                activity.startActivity(dialIntent);
            });
        }

        // REPORT ISSUE ACTION -> OPENS DEDICATED REPORT ISSUE UI
        if (btnReportIssue != null) {
            btnReportIssue.setOnClickListener(v -> new report_issue_area().setupReportIssue(activity));
        }

        activity.setupBottomNav();
        activity.updateCartBadges();
    }
}