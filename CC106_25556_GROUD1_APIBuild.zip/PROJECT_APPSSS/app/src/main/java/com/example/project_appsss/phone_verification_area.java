package com.example.project_appsss;

import com.example.project_appsss.R;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

public class phone_verification_area {

    public void setupVerification(MainActivity activity) {
        activity.setContentView(R.layout.phone_verification_area);

        EditText etVerifyPhoneNumber = activity.findViewById(R.id.etVerifyPhoneNumber);
        EditText etVerifyCode = activity.findViewById(R.id.etVerifyCode);
        View btnSubmitVerification = activity.findViewById(R.id.btnSubmitVerification);
        View btnBackFromVerify = activity.findViewById(R.id.btnBackFromVerify);

        if (etVerifyPhoneNumber != null && !activity.registeredPhone.isEmpty()) {
            etVerifyPhoneNumber.setText(activity.registeredPhone);
        }

        if (btnBackFromVerify != null) {
            btnBackFromVerify.setOnClickListener(v -> activity.showHomeScreen());
        }

        if (btnSubmitVerification != null) {
            btnSubmitVerification.setOnClickListener(v -> {
                String phone = etVerifyPhoneNumber != null ? etVerifyPhoneNumber.getText().toString().trim() : "";
                String code = etVerifyCode != null ? etVerifyCode.getText().toString().trim() : "";

                if (phone.length() < 10) {
                    Toast.makeText(activity, "Please enter a valid phone number!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (code.length() < 4) {
                    Toast.makeText(activity, "Please enter the verification code!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Mark user as verified locally
                activity.registeredPhone = phone;
                activity.isPhoneVerified = true;

                new AlertDialog.Builder(activity)
                        .setTitle("Phone Verified Success!")
                        .setMessage("Your account is now verified. You can proceed with placing orders.")
                        .setPositiveButton("OK", (dialog, which) -> activity.showHomeScreen())
                        .setCancelable(false)
                        .show();
            });
        }
    }
}
