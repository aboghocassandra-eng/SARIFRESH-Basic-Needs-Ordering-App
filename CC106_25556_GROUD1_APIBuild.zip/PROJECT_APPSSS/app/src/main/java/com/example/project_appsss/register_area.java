package com.example.project_appsss;

import com.example.project_appsss.R;

import android.content.Intent;
import android.text.InputType;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class register_area {

    private boolean isPasswordVisible = false;
    private boolean isConfirmPasswordVisible = false;

    public void setupRegister(MainActivity activity) {
        activity.setContentView(R.layout.register_area);

        EditText etEmail = activity.findViewById(R.id.etRegisterEmail);
        EditText etName = activity.findViewById(R.id.etRegisterName);
        EditText etPassword = activity.findViewById(R.id.etRegisterPassword);
        EditText etConfirmPassword = activity.findViewById(R.id.etRegisterConfirmPassword);
        Button btnSignUp = activity.findViewById(R.id.btnRegisterSubmit);
        Button btnGoogleRegister = activity.findViewById(R.id.btnGoogleRegister);
        TextView tvTabLogin = activity.findViewById(R.id.tvTabLogin);

        // ====================================================
        // PASSWORD VISIBILITY TOGGLES (SHOW/HIDE)
        // ====================================================
        if (etPassword != null) {
            setupPasswordToggle(etPassword, true);
        }
        if (etConfirmPassword != null) {
            setupPasswordToggle(etConfirmPassword, false);
        }

        // Switch back to Login Screen
        if (tvTabLogin != null) {
            tvTabLogin.setOnClickListener(v -> activity.showLoginScreen());
        }

        // Registration Submission
        if (btnSignUp != null) {
            btnSignUp.setOnClickListener(v -> {
                String email = (etEmail != null) ? etEmail.getText().toString().trim() : "";
                String name = (etName != null) ? etName.getText().toString().trim() : "";
                String password = (etPassword != null) ? etPassword.getText().toString().trim() : "";
                String confirmPassword = (etConfirmPassword != null) ? etConfirmPassword.getText().toString().trim() : "";

                if (email.isEmpty() || name.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    Toast.makeText(activity, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(activity, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(activity, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Register user in Firebase Authentication
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                                if (firebaseUser != null) {
                                    String uid = firebaseUser.getUid();

                                    // Save user profile (name, email) into Realtime Database
                                    Map<String, Object> userMap = new HashMap<>();
                                    userMap.put("name", name);
                                    userMap.put("email", email);

                                    FirebaseDatabase.getInstance(MainActivity.DB_URL)
                                            .getReference("users")
                                            .child(uid)
                                            .setValue(userMap);
                                }

                                // Keep MainActivity variables updated
                                activity.registeredEmail = email;
                                activity.registeredName = name;
                                activity.registeredPassword = password;
                                activity.isPhoneVerified = false;

                                Toast.makeText(activity, "Account created successfully!", Toast.LENGTH_SHORT).show();
                                activity.showHomeScreen();
                            } else {
                                String errorMessage = (task.getException() != null)
                                        ? task.getException().getMessage()
                                        : "Registration failed";
                                Toast.makeText(activity, "Error: " + errorMessage, Toast.LENGTH_LONG).show();
                            }
                        });
            });
        }

        // ====================================================
        // REAL GOOGLE SIGN-UP LISTENER
        // ====================================================
        if (btnGoogleRegister != null) {
            btnGoogleRegister.setOnClickListener(v -> performGoogleSignIn(activity));
        }
    }

    // ====================================================
    // DYNAMIC PASSWORD VISIBILITY TOGGLE HANDLER
    // ====================================================
    private void setupPasswordToggle(EditText editText, boolean isMainPassword) {
        editText.setOnTouchListener((v, event) -> {
            final int DRAWABLE_RIGHT = 2;
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (editText.getCompoundDrawables()[DRAWABLE_RIGHT] != null) {
                    if (event.getRawX() >= (editText.getRight() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        boolean isVisible = isMainPassword ? isPasswordVisible : isConfirmPasswordVisible;

                        if (isVisible) {
                            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                        } else {
                            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                        }

                        if (isMainPassword) {
                            isPasswordVisible = !isPasswordVisible;
                        } else {
                            isConfirmPasswordVisible = !isConfirmPasswordVisible;
                        }

                        editText.setSelection(editText.getText().length());
                        return true;
                    }
                }
            }
            return false;
        });
    }

    // ====================================================
    // GOOGLE SIGN-IN LAUNCHER
    // ====================================================
    private void performGoogleSignIn(MainActivity activity) {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("YOUR_ACTUAL_WEB_CLIENT_ID.apps.googleusercontent.com")
                .requestEmail()
                .build();

        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(activity, gso);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        activity.startActivityForResult(signInIntent, 9001);
    }
}