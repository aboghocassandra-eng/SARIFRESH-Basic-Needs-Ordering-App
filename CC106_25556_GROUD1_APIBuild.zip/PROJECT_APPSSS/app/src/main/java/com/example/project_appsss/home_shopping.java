package com.example.project_appsss;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class home_shopping {

    public void setupHome(MainActivity activity) {
        activity.setContentView(R.layout.home_page_area);

        TextView tvUserName = activity.findViewById(R.id.tvUserName);
        TextView tvDeliverLocation = activity.findViewById(R.id.tvDeliverLocation);
        ImageView btnCart = activity.findViewById(R.id.btnCart);

        // 1. DYNAMIC USER NAME FROM FIREBASE AUTH / DATABASE
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String uid = currentUser.getUid();
            FirebaseDatabase.getInstance(MainActivity.DB_URL)
                    .getReference("users")
                    .child(uid)
                    .child("name")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            if (snapshot.exists() && snapshot.getValue(String.class) != null) {
                                String name = snapshot.getValue(String.class);
                                activity.registeredName = name;
                                if (tvUserName != null) {
                                    tvUserName.setText(name);
                                }
                            } else if (tvUserName != null && !activity.registeredName.isEmpty()) {
                                tvUserName.setText(activity.registeredName);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            if (tvUserName != null && !activity.registeredName.isEmpty()) {
                                tvUserName.setText(activity.registeredName);
                            }
                        }
                    });
        } else if (tvUserName != null && !activity.registeredName.isEmpty()) {
            tvUserName.setText(activity.registeredName);
        }

        // 2. LOCATION & CART LISTENERS
        if (tvDeliverLocation != null) {
            tvDeliverLocation.setOnClickListener(v -> activity.showMapScreen());
        }

        if (btnCart != null) {
            btnCart.setOnClickListener(v -> activity.showOrdersScreen());
        }

        // 3. CATEGORY BUTTON CLICK LISTENERS
        LinearLayout catRice = activity.findViewById(R.id.catRice);
        LinearLayout catEggs = activity.findViewById(R.id.catEggs);
        LinearLayout catOils = activity.findViewById(R.id.btnOils); // Mapped to btnOils ID in home_page_area.xml
        LinearLayout catFrozen = activity.findViewById(R.id.catFrozen);

        if (catRice != null) catRice.setOnClickListener(v -> activity.showRiceScreen());
        if (catEggs != null) catEggs.setOnClickListener(v -> activity.showEggsScreen());
        if (catOils != null) catOils.setOnClickListener(v -> activity.showOilScreen());
        if (catFrozen != null) catFrozen.setOnClickListener(v -> activity.showFrozenScreen());

        // 4. BOTTOM NAVIGATION & BADGE SYNCHRONIZATION
        activity.setupBottomNav();
        activity.updateCartBadges();
    }
}