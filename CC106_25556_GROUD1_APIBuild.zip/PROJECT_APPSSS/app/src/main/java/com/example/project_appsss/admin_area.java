package com.example.project_appsss;

import com.example.project_appsss.R;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class admin_area {

    private String currentCategoryFilter = "All";

    public void setupAdmin(MainActivity activity) {
        activity.setContentView(R.layout.admin_area);

        // Bind UI Components
        ImageView btnBackFromAdmin = activity.findViewById(R.id.btnBackFromAdmin);
        TextView tabPendingOrders = activity.findViewById(R.id.tabPendingOrders);
        TextView tabPastOrders = activity.findViewById(R.id.tabPastOrders);
        TextView tabManageInventory = activity.findViewById(R.id.tabManageInventory);

        View btnAdminReports = activity.findViewById(R.id.btnAdminReports);
        TextView tvReportBadgeCount = activity.findViewById(R.id.tvReportBadgeCount);

        ScrollView svOrdersQueueContainer = activity.findViewById(R.id.svOrdersQueueContainer);
        ScrollView svPastOrdersContainer = activity.findViewById(R.id.svPastOrdersContainer);
        View rlInventoryContainer = activity.findViewById(R.id.rlInventoryContainer);
        View btnAddProduct = activity.findViewById(R.id.btnAddProduct);

        // Navigation Back Button
        if (btnBackFromAdmin != null) {
            btnBackFromAdmin.setOnClickListener(v -> activity.showHomeScreen());
        }

        // ====================================================
        // REALTIME LISTENER FOR CUSTOMER REPORTED ISSUES
        // ====================================================
        listenForReportedIssues(activity, tvReportBadgeCount, btnAdminReports);

        // Tab Switching Logic (Pending | Past Orders | Inventory)
        if (tabPendingOrders != null && tabPastOrders != null && tabManageInventory != null) {
            tabPendingOrders.setOnClickListener(v -> {
                tabPendingOrders.setBackgroundColor(Color.parseColor("#2A4836"));
                tabPendingOrders.setTextColor(Color.WHITE);

                tabPastOrders.setBackgroundColor(Color.TRANSPARENT);
                tabPastOrders.setTextColor(Color.parseColor("#2A4836"));

                tabManageInventory.setBackgroundColor(Color.TRANSPARENT);
                tabManageInventory.setTextColor(Color.parseColor("#2A4836"));

                if (svOrdersQueueContainer != null) svOrdersQueueContainer.setVisibility(View.VISIBLE);
                if (svPastOrdersContainer != null) svPastOrdersContainer.setVisibility(View.GONE);
                if (rlInventoryContainer != null) rlInventoryContainer.setVisibility(View.GONE);
                loadOrdersQueue(activity);
            });

            tabPastOrders.setOnClickListener(v -> {
                tabPastOrders.setBackgroundColor(Color.parseColor("#2A4836"));
                tabPastOrders.setTextColor(Color.WHITE);

                tabPendingOrders.setBackgroundColor(Color.TRANSPARENT);
                tabPendingOrders.setTextColor(Color.parseColor("#2A4836"));

                tabManageInventory.setBackgroundColor(Color.TRANSPARENT);
                tabManageInventory.setTextColor(Color.parseColor("#2A4836"));

                if (svOrdersQueueContainer != null) svOrdersQueueContainer.setVisibility(View.GONE);
                if (svPastOrdersContainer != null) svPastOrdersContainer.setVisibility(View.VISIBLE);
                if (rlInventoryContainer != null) rlInventoryContainer.setVisibility(View.GONE);
                loadOrdersQueue(activity);
            });

            tabManageInventory.setOnClickListener(v -> {
                tabManageInventory.setBackgroundColor(Color.parseColor("#2A4836"));
                tabManageInventory.setTextColor(Color.WHITE);

                tabPendingOrders.setBackgroundColor(Color.TRANSPARENT);
                tabPendingOrders.setTextColor(Color.parseColor("#2A4836"));

                tabPastOrders.setBackgroundColor(Color.TRANSPARENT);
                tabPastOrders.setTextColor(Color.parseColor("#2A4836"));

                if (svOrdersQueueContainer != null) svOrdersQueueContainer.setVisibility(View.GONE);
                if (svPastOrdersContainer != null) svPastOrdersContainer.setVisibility(View.GONE);
                if (rlInventoryContainer != null) rlInventoryContainer.setVisibility(View.VISIBLE);
                loadInventoryList(activity);
            });
        }

        // Add Product Listener
        if (btnAddProduct != null) {
            btnAddProduct.setOnClickListener(v -> showAddProductDialog(activity));
        }

        // Initial Load
        loadOrdersQueue(activity);
    }

    // ====================================================
    // REALTIME REPORTED ISSUES BADGE & DIALOG
    // ====================================================
    private void listenForReportedIssues(MainActivity activity, TextView tvBadge, View btnReports) {
        DatabaseReference reportsRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("reports");

        reportsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                long count = snapshot.getChildrenCount();

                if (count > 0) {
                    if (tvBadge != null) {
                        tvBadge.setText(String.valueOf(count));
                        tvBadge.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (tvBadge != null) {
                        tvBadge.setVisibility(View.GONE);
                    }
                }

                if (btnReports != null) {
                    btnReports.setOnClickListener(v -> showReportedIssuesDialog(activity, snapshot, reportsRef));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Silently ignore or handle error
            }
        });
    }

    private void showReportedIssuesDialog(MainActivity activity, DataSnapshot snapshot, DatabaseReference reportsRef) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("🚨 Customer Issue Reports");

        ScrollView scrollView = new ScrollView(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 16);

        if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
            TextView tvEmpty = new TextView(activity);
            tvEmpty.setText("No unresolved customer reports.");
            tvEmpty.setTextColor(Color.GRAY);
            tvEmpty.setTextSize(14);
            tvEmpty.setPadding(0, 16, 0, 16);
            layout.addView(tvEmpty);
        } else {
            for (DataSnapshot reportSnap : snapshot.getChildren()) {
                String key = reportSnap.getKey();
                String user = reportSnap.child("user").getValue(String.class);
                String issueType = reportSnap.child("issueType").getValue(String.class);
                String orderRef = reportSnap.child("orderRef").getValue(String.class);
                String description = reportSnap.child("description").getValue(String.class);

                // Fallback check if reported under legacy 'issue' key
                if (description == null) {
                    description = reportSnap.child("issue").getValue(String.class);
                }

                CardView card = new CardView(activity);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                p.setMargins(0, 0, 0, 20);
                card.setLayoutParams(p);
                card.setCardBackgroundColor(Color.parseColor("#FFF3E0"));
                card.setRadius(12);
                card.setCardElevation(3);

                LinearLayout cardLayout = new LinearLayout(activity);
                cardLayout.setOrientation(LinearLayout.VERTICAL);
                cardLayout.setPadding(20, 20, 20, 20);

                // Reporter Name
                TextView tvUser = new TextView(activity);
                tvUser.setText("Reporter: " + (user != null ? user : "Customer"));
                tvUser.setTypeface(null, Typeface.BOLD);
                tvUser.setTextSize(15);
                tvUser.setTextColor(Color.parseColor("#1A1A1A"));

                // Issue Category
                TextView tvType = new TextView(activity);
                tvType.setText("Category: " + (issueType != null ? issueType : "General Inquiry"));
                tvType.setTypeface(null, Typeface.BOLD);
                tvType.setTextSize(13);
                tvType.setTextColor(Color.parseColor("#E65100"));
                tvType.setPadding(0, 4, 0, 4);

                // Order Reference
                TextView tvOrder = new TextView(activity);
                tvOrder.setText("Order Ref: " + (orderRef != null ? orderRef : "None"));
                tvOrder.setTextSize(13);
                tvOrder.setTextColor(Color.parseColor("#444444"));

                // Issue Description
                TextView tvDesc = new TextView(activity);
                tvDesc.setText("Details: " + (description != null ? description : "No detail provided"));
                tvDesc.setTextSize(13);
                tvDesc.setTextColor(Color.parseColor("#222222"));
                tvDesc.setPadding(0, 6, 0, 12);

                // Resolve Action Button
                TextView btnResolve = new TextView(activity);
                btnResolve.setText("  Mark as Resolved ✔  ");
                btnResolve.setTextColor(Color.WHITE);
                btnResolve.setBackgroundColor(Color.parseColor("#2E7D32"));
                btnResolve.setTypeface(null, Typeface.BOLD);
                btnResolve.setTextSize(12);
                btnResolve.setPadding(16, 12, 16, 12);
                btnResolve.setGravity(Gravity.CENTER);

                btnResolve.setOnClickListener(v -> {
                    if (key != null) {
                        reportsRef.child(key).removeValue();
                        Toast.makeText(activity, "Report resolved and cleared!", Toast.LENGTH_SHORT).show();
                    }
                });

                cardLayout.addView(tvUser);
                cardLayout.addView(tvType);
                cardLayout.addView(tvOrder);
                cardLayout.addView(tvDesc);
                cardLayout.addView(btnResolve);

                card.addView(cardLayout);
                layout.addView(card);
            }
        }

        scrollView.addView(layout);
        builder.setView(scrollView);
        builder.setPositiveButton("Close", null);
        builder.show();
    }

    // ====================================================
    // 1. ORDERS QUEUE (PENDING & PAST ORDERS FIREBASE LISTENER)
    // ====================================================
    private void loadOrdersQueue(MainActivity activity) {
        LinearLayout containerOrdersList = activity.findViewById(R.id.containerOrdersList);
        LinearLayout containerPastOrdersList = activity.findViewById(R.id.containerPastOrdersList);

        DatabaseReference ordersRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("orders");
        ordersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (containerOrdersList != null) containerOrdersList.removeAllViews();
                if (containerPastOrdersList != null) containerPastOrdersList.removeAllViews();

                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    showEmptyMessage(containerOrdersList, "No pending orders in the queue.");
                    showEmptyMessage(containerPastOrdersList, "No past order history.");
                    return;
                }

                int pendingCount = 0;
                int pastCount = 0;

                for (DataSnapshot orderSnap : snapshot.getChildren()) {
                    MainActivity.CustomerOrder order = orderSnap.getValue(MainActivity.CustomerOrder.class);
                    if (order != null) {
                        order.orderId = orderSnap.getKey();
                        String status = (order.status != null) ? order.status.toUpperCase() : "PENDING";

                        if (status.equals("PENDING")) {
                            pendingCount++;
                            if (containerOrdersList != null) {
                                renderOrderCard(activity, containerOrdersList, order, ordersRef, true);
                            }
                        } else {
                            pastCount++;
                            if (containerPastOrdersList != null) {
                                renderOrderCard(activity, containerPastOrdersList, order, ordersRef, false);
                            }
                        }
                    }
                }

                if (pendingCount == 0 && containerOrdersList != null) {
                    showEmptyMessage(containerOrdersList, "No pending orders in the queue.");
                }

                if (pastCount == 0 && containerPastOrdersList != null) {
                    showEmptyMessage(containerPastOrdersList, "No past order history.");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(activity, "Failed to load orders: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void renderOrderCard(MainActivity activity, LinearLayout container, MainActivity.CustomerOrder order, DatabaseReference ordersRef, boolean isPending) {
        CardView card = new CardView(activity);
        CardView.LayoutParams cardParams = new CardView.LayoutParams(
                CardView.LayoutParams.MATCH_PARENT, CardView.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, 24);
        card.setLayoutParams(cardParams);
        card.setRadius(16);
        card.setCardBackgroundColor(Color.WHITE);
        card.setCardElevation(3);

        LinearLayout orderLayout = new LinearLayout(activity);
        orderLayout.setOrientation(LinearLayout.VERTICAL);
        orderLayout.setPadding(24, 24, 24, 24);

        TextView tvCustomer = new TextView(activity);
        tvCustomer.setText("Customer: " + order.customerName);
        tvCustomer.setTextSize(16);
        tvCustomer.setTypeface(null, Typeface.BOLD);
        tvCustomer.setTextColor(Color.parseColor("#1A1A1A"));

        // PHONE NUMBER + CALL BUTTON ROW
        LinearLayout phoneRow = new LinearLayout(activity);
        phoneRow.setOrientation(LinearLayout.HORIZONTAL);
        phoneRow.setGravity(Gravity.CENTER_VERTICAL);
        phoneRow.setPadding(0, 4, 0, 8);

        TextView tvPhone = new TextView(activity);
        tvPhone.setText("Phone: " + order.contactNumber + (order.isPhoneVerified ? " (VERIFIED)" : " (UNVERIFIED)"));
        tvPhone.setTextSize(13);
        tvPhone.setTextColor(order.isPhoneVerified ? Color.parseColor("#2E7D32") : Color.parseColor("#D32F2F"));
        tvPhone.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams phoneTextParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        tvPhone.setLayoutParams(phoneTextParams);

        // DIRECT CALL BUTTON
        TextView btnCallCustomer = new TextView(activity);
        btnCallCustomer.setText(" 📞 Call ");
        btnCallCustomer.setTextSize(12);
        btnCallCustomer.setTypeface(null, Typeface.BOLD);
        btnCallCustomer.setTextColor(Color.WHITE);
        btnCallCustomer.setBackgroundColor(Color.parseColor("#1B5E20"));
        btnCallCustomer.setPadding(16, 8, 16, 8);

        btnCallCustomer.setOnClickListener(v -> {
            if (order.contactNumber != null && !order.contactNumber.trim().isEmpty()) {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:" + order.contactNumber.trim()));
                activity.startActivity(dialIntent);
            } else {
                Toast.makeText(activity, "No phone number available for this customer.", Toast.LENGTH_SHORT).show();
            }
        });

        phoneRow.addView(tvPhone);
        phoneRow.addView(btnCallCustomer);

        TextView tvAddress = new TextView(activity);
        tvAddress.setText("Delivery Address: " + order.deliveryAddress);
        tvAddress.setTextSize(13);
        tvAddress.setTextColor(Color.parseColor("#444444"));

        TextView tvNotes = new TextView(activity);
        String notesStr = (order.specialInstructions != null && !order.specialInstructions.isEmpty()) ? order.specialInstructions : "None";
        tvNotes.setText("Special Notes: " + notesStr);
        tvNotes.setTextSize(12);
        tvNotes.setTextColor(Color.GRAY);
        tvNotes.setPadding(0, 4, 0, 8);

        TextView tvPayment = new TextView(activity);
        String paymentStr = (order.paymentMethod != null && !order.paymentMethod.isEmpty()) ? order.paymentMethod : "Cash on Delivery";
        tvPayment.setText("Payment Method: " + paymentStr);
        tvPayment.setTextSize(13);
        tvPayment.setTypeface(null, Typeface.BOLD);
        tvPayment.setTextColor(Color.parseColor("#2A4836"));
        tvPayment.setPadding(0, 0, 0, 12);

        StringBuilder itemsText = new StringBuilder("Ordered Items:\n");
        if (order.items != null) {
            for (MainActivity.CartItem item : order.items) {
                itemsText.append("• ").append(item.itemName)
                        .append(" (x").append(item.quantity).append(" ").append(item.unitLabel).append(") - ₱")
                        .append((int) item.getTotalPrice()).append("\n");
            }
        }
        TextView tvItems = new TextView(activity);
        tvItems.setText(itemsText.toString().trim());
        tvItems.setTextSize(13);
        tvItems.setTextColor(Color.parseColor("#222222"));

        TextView tvTotal = new TextView(activity);
        tvTotal.setText("Total Amount: ₱" + order.totalAmount);
        tvTotal.setTextSize(16);
        tvTotal.setTypeface(null, Typeface.BOLD);
        tvTotal.setTextColor(Color.parseColor("#2A4836"));
        tvTotal.setPadding(0, 12, 0, 16);

        TextView tvStatus = new TextView(activity);
        tvStatus.setText("Status: " + order.status);
        tvStatus.setTextSize(13);
        tvStatus.setTypeface(null, Typeface.BOLD);

        if ("ACCEPTED".equalsIgnoreCase(order.status)) {
            tvStatus.setTextColor(Color.parseColor("#2E7D32"));
        } else if ("REJECTED".equalsIgnoreCase(order.status)) {
            tvStatus.setTextColor(Color.parseColor("#D32F2F"));
        } else {
            tvStatus.setTextColor(Color.parseColor("#E65100"));
        }

        orderLayout.addView(tvCustomer);
        orderLayout.addView(phoneRow);
        orderLayout.addView(tvAddress);
        orderLayout.addView(tvNotes);
        orderLayout.addView(tvPayment);
        orderLayout.addView(tvItems);
        orderLayout.addView(tvTotal);
        orderLayout.addView(tvStatus);

        if (isPending) {
            LinearLayout buttonRow = new LinearLayout(activity);
            buttonRow.setOrientation(LinearLayout.HORIZONTAL);
            buttonRow.setPadding(0, 12, 0, 0);

            TextView btnAccept = new TextView(activity);
            btnAccept.setText(" Accept Order ");
            btnAccept.setTextSize(13);
            btnAccept.setTypeface(null, Typeface.BOLD);
            btnAccept.setTextColor(Color.WHITE);
            btnAccept.setBackgroundColor(Color.parseColor("#2A4836"));
            btnAccept.setPadding(24, 16, 24, 16);

            TextView btnReject = new TextView(activity);
            btnReject.setText(" Reject ");
            btnReject.setTextSize(13);
            btnReject.setTypeface(null, Typeface.BOLD);
            btnReject.setTextColor(Color.WHITE);
            btnReject.setBackgroundColor(Color.parseColor("#D32F2F"));
            btnReject.setPadding(24, 16, 24, 16);

            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            btnParams.setMargins(0, 0, 12, 0);
            btnAccept.setLayoutParams(btnParams);

            btnAccept.setOnClickListener(v -> {
                ordersRef.child(order.orderId).child("status").setValue("ACCEPTED");
                Toast.makeText(activity, "Order accepted for " + order.customerName, Toast.LENGTH_SHORT).show();
            });

            btnReject.setOnClickListener(v -> {
                ordersRef.child(order.orderId).child("status").setValue("REJECTED");
                Toast.makeText(activity, "Order rejected.", Toast.LENGTH_SHORT).show();
            });

            buttonRow.addView(btnAccept);
            buttonRow.addView(btnReject);
            orderLayout.addView(buttonRow);
        }

        card.addView(orderLayout);
        container.addView(card);
    }

    private void showEmptyMessage(LinearLayout container, String message) {
        if (container == null) return;
        TextView tvEmpty = new TextView(container.getContext());
        tvEmpty.setText(message);
        tvEmpty.setTextColor(Color.GRAY);
        tvEmpty.setTextSize(14);
        tvEmpty.setPadding(0, 32, 0, 0);
        tvEmpty.setGravity(Gravity.CENTER);
        container.addView(tvEmpty);
    }

    // ====================================================
    // 2. INVENTORY MANAGEMENT WITH CATEGORY SELECTION
    // ====================================================
    private void loadInventoryList(MainActivity activity) {
        LinearLayout containerInventoryList = activity.findViewById(R.id.containerInventoryList);
        if (containerInventoryList == null) return;

        DatabaseReference productsRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("products");
        productsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerInventoryList.removeAllViews();

                LinearLayout filterBar = createCategoryFilterBar(activity);
                containerInventoryList.addView(filterBar);

                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    showEmptyMessage(containerInventoryList, "No inventory items found.");
                    return;
                }

                int displayedItemCount = 0;

                for (DataSnapshot itemSnap : snapshot.getChildren()) {
                    MainActivity.ProductItem product = itemSnap.getValue(MainActivity.ProductItem.class);
                    if (product != null) {
                        product.id = itemSnap.getKey();

                        if (!currentCategoryFilter.equalsIgnoreCase("All") &&
                                (product.category == null || !product.category.equalsIgnoreCase(currentCategoryFilter))) {
                            continue;
                        }

                        displayedItemCount++;

                        CardView card = new CardView(activity);
                        CardView.LayoutParams cardParams = new CardView.LayoutParams(
                                CardView.LayoutParams.MATCH_PARENT, CardView.LayoutParams.WRAP_CONTENT);
                        cardParams.setMargins(0, 0, 0, 16);
                        card.setLayoutParams(cardParams);
                        card.setRadius(12);
                        card.setCardBackgroundColor(Color.WHITE);
                        card.setCardElevation(2);

                        LinearLayout itemRow = new LinearLayout(activity);
                        itemRow.setOrientation(LinearLayout.HORIZONTAL);
                        itemRow.setPadding(20, 20, 20, 20);
                        itemRow.setGravity(Gravity.CENTER_VERTICAL);

                        LinearLayout detailsLayout = new LinearLayout(activity);
                        detailsLayout.setOrientation(LinearLayout.VERTICAL);
                        LinearLayout.LayoutParams detParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
                        detailsLayout.setLayoutParams(detParams);

                        TextView tvName = new TextView(activity);
                        String categoryLabel = (product.category != null && !product.category.isEmpty()) ? " [" + product.category + "]" : "";
                        tvName.setText(product.name + categoryLabel);
                        tvName.setTextSize(15);
                        tvName.setTypeface(null, Typeface.BOLD);
                        tvName.setTextColor(Color.parseColor("#1A1A1A"));

                        TextView tvPrice = new TextView(activity);
                        tvPrice.setText("₱" + (int) product.price + " / " + product.unit);
                        tvPrice.setTextSize(13);
                        tvPrice.setTextColor(Color.parseColor("#666666"));

                        detailsLayout.addView(tvName);
                        detailsLayout.addView(tvPrice);

                        TextView btnToggle = new TextView(activity);
                        btnToggle.setText(product.isAvailable ? "In Stock" : "Out of Stock");
                        btnToggle.setTextSize(12);
                        btnToggle.setTypeface(null, Typeface.BOLD);
                        btnToggle.setPadding(16, 12, 16, 12);
                        btnToggle.setTextColor(Color.WHITE);
                        btnToggle.setBackgroundColor(product.isAvailable ? Color.parseColor("#2E7D32") : Color.parseColor("#E65100"));

                        btnToggle.setOnClickListener(v -> {
                            boolean newStatus = !product.isAvailable;
                            productsRef.child(product.id).child("isAvailable").setValue(newStatus);
                            Toast.makeText(activity, product.name + (newStatus ? " set to Available" : " set to Unavailable"), Toast.LENGTH_SHORT).show();
                        });

                        TextView btnRemove = new TextView(activity);
                        btnRemove.setText(" ✕ ");
                        btnRemove.setTextSize(16);
                        btnRemove.setTextColor(Color.parseColor("#D32F2F"));
                        btnRemove.setPadding(16, 8, 8, 8);
                        btnRemove.setOnClickListener(v -> {
                            new AlertDialog.Builder(activity)
                                    .setTitle("Remove Product")
                                    .setMessage("Are you sure you want to remove " + product.name + " from the store?")
                                    .setPositiveButton("Remove", (dialog, which) -> {
                                        productsRef.child(product.id).removeValue();
                                        Toast.makeText(activity, product.name + " removed from store", Toast.LENGTH_SHORT).show();
                                    })
                                    .setNegativeButton("Cancel", null)
                                    .show();
                        });

                        itemRow.addView(detailsLayout);
                        itemRow.addView(btnToggle);
                        itemRow.addView(btnRemove);

                        card.addView(itemRow);
                        containerInventoryList.addView(card);
                    }
                }

                if (displayedItemCount == 0) {
                    showEmptyMessage(containerInventoryList, "No products listed under \"" + currentCategoryFilter + "\".");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(activity, "Failed to load inventory: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private LinearLayout createCategoryFilterBar(MainActivity activity) {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setPadding(0, 0, 0, 24);

        String[] filters = {"All", "Rice", "Eggs", "Oils", "Frozen"};

        for (String filter : filters) {
            TextView btnFilter = new TextView(activity);
            btnFilter.setText(filter);
            btnFilter.setTextSize(12);
            btnFilter.setTypeface(null, Typeface.BOLD);
            btnFilter.setPadding(20, 12, 20, 12);

            boolean isSelected = currentCategoryFilter.equalsIgnoreCase(filter);
            btnFilter.setTextColor(isSelected ? Color.WHITE : Color.parseColor("#2A4836"));
            btnFilter.setBackgroundColor(isSelected ? Color.parseColor("#2A4836") : Color.parseColor("#E3EBDC"));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 12, 0);
            btnFilter.setLayoutParams(params);

            btnFilter.setOnClickListener(v -> {
                currentCategoryFilter = filter;
                loadInventoryList(activity);
            });

            layout.addView(btnFilter);
        }

        return layout;
    }

    // ====================================================
    // 3. ADD PRODUCT DIALOG (WITH CATEGORY DROP-DOWN)
    // ====================================================
    private void showAddProductDialog(MainActivity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Add New Store Product");

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 16, 32, 16);

        TextView tvCatLabel = new TextView(activity);
        tvCatLabel.setText("Category:");
        tvCatLabel.setTextSize(13);
        tvCatLabel.setTextColor(Color.parseColor("#444444"));

        Spinner spinnerCategory = new Spinner(activity);
        String[] categories = {"Rice", "Eggs", "Oils", "Frozen"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item, categories);
        spinnerCategory.setAdapter(adapter);

        EditText etName = new EditText(activity);
        etName.setHint("Product Name (e.g. Jasmine Rice)");

        EditText etPrice = new EditText(activity);
        etPrice.setHint("Price in ₱");
        etPrice.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        EditText etUnit = new EditText(activity);
        etUnit.setHint("Unit Label (e.g. kg, pc, bottle, pack)");

        layout.addView(tvCatLabel);
        layout.addView(spinnerCategory);
        layout.addView(etName);
        layout.addView(etPrice);
        layout.addView(etUnit);

        builder.setView(layout);

        builder.setPositiveButton("Add Product", (dialog, which) -> {
            String category = spinnerCategory.getSelectedItem().toString();
            String name = etName.getText().toString().trim();
            String priceStr = etPrice.getText().toString().trim();
            String unit = etUnit.getText().toString().trim();

            if (!name.isEmpty() && !priceStr.isEmpty()) {
                double price = Double.parseDouble(priceStr);
                String unitLabel = unit.isEmpty() ? "pc" : unit;

                DatabaseReference productsRef = FirebaseDatabase.getInstance(MainActivity.DB_URL).getReference("products");
                String key = productsRef.push().getKey();

                if (key != null) {
                    MainActivity.ProductItem newItem = new MainActivity.ProductItem(key, name, category, price, unitLabel, true);
                    productsRef.child(key).setValue(newItem)
                            .addOnSuccessListener(aVoid -> Toast.makeText(activity, name + " added to " + category + "!", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e -> Toast.makeText(activity, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            } else {
                Toast.makeText(activity, "Please enter product name and price", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}