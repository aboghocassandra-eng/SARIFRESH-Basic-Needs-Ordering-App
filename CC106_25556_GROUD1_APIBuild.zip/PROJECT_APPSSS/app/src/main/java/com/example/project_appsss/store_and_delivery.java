package com.example.project_appsss;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import org.osmdroid.config.Configuration;

public class store_and_delivery {

    public void setupStoreAndDelivery(MainActivity activity) {
        try {
            Context context = activity.getApplicationContext();
            Configuration.getInstance().setUserAgentValue("SariFreshDavaoDeliveryApp_v1_0");
        } catch (Exception e) {
            e.printStackTrace();
        }

        activity.setContentView(R.layout.map_order_area);

        // Initialize Map Engine
        if (activity.mapManager == null) {
            activity.mapManager = new MapManager();
        }
        activity.mapManager.setupMap(activity);

        // ====================================================
        // 1. TOP HEADER BACK BUTTON
        // ====================================================
        ImageButton btnBackMap = activity.findViewById(R.id.btnBackMap);
        if (btnBackMap != null) {
            btnBackMap.setOnClickListener(v -> activity.showHomeScreen());
        }

        // ====================================================
        // 2. CONFIRM LOCATION BUTTON (REDIRECTS TO ORDERS AREA)
        // ====================================================
        Button btnConfirmLocation = activity.findViewById(R.id.btnConfirmLocation);
        if (btnConfirmLocation != null) {
            btnConfirmLocation.setOnClickListener(v -> {
                if (activity.selectedDeliveryAddress == null || activity.selectedDeliveryAddress.trim().isEmpty()) {
                    activity.selectedDeliveryAddress = "Communal, Buhangin, Davao City";
                }

                Toast.makeText(activity, "Delivery address confirmed!", Toast.LENGTH_SHORT).show();

                // Redirect to Orders Area directly
                new oder_area().setupOrder(activity);
            });
        }

        // ====================================================
        // 3. BOTTOM NAVIGATION BAR LISTENERS
        // ====================================================
        View navHome = activity.findViewById(R.id.navCategoryHome);
        if (navHome != null) {
            navHome.setOnClickListener(v -> activity.showHomeScreen());
        }

        View navOrders = activity.findViewById(R.id.navCategoryOrders);
        if (navOrders != null) {
            navOrders.setOnClickListener(v -> new oder_area().setupOrder(activity));
        }

        View navProfile = activity.findViewById(R.id.navCategoryProfile);
        if (navProfile != null) {
            navProfile.setOnClickListener(v -> new user_profile_area().setupProfile(activity));
        }

        activity.updateCartBadges();
    }
}