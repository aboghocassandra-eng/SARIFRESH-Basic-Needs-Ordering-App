package com.example.project_appsss;

import com.example.project_appsss.R;

import android.content.Intent;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class login_area {

    private boolean isPasswordVisible = false;

    public void setupLogin(MainActivity activity) {
        activity.setContentView(R.layout.login_area);

        EditText etEmail = activity.findViewById(R.id.etEmail);
        EditText etPassword = activity.findViewById(R.id.etPassword);
        Button btnLogin = activity.findViewById(R.id.btnLogin);
        TextView tvTabSignup = activity.findViewById(R.id.tvTabSignup);
        View btnGoogle = activity.findViewById(R.id.btnGoogleLogin); // Google Sign-In Button

        // ====================================================
        // PASSWORD VISIBILITY TOGGLE (SHOW/HIDE)
        // ====================================================
        if (etPassword != null) {
            setupPasswordToggle(etPassword);
        }

        if (tvTabSignup != null) {
            tvTabSignup.setOnClickListener(v -> activity.showRegisterScreen());
        }

        // ====================================================
        // GOOGLE SIGN-IN LISTENER (FREE AUTHENTICATION)
        // ====================================================
        if (btnGoogle != null) {
            btnGoogle.setOnClickListener(v -> performGoogleSignIn(activity));
        }

        if (btnLogin != null) {
            btnLogin.setOnClickListener(v -> {
                String inputEmail = (etEmail != null) ? etEmail.getText().toString().trim() : "";
                String inputPassword = (etPassword != null) ? etPassword.getText().toString().trim() : "";

                // Input Validations
                if (inputEmail.isEmpty()) {
                    if (etEmail != null) {
                        etEmail.setError("Please enter your email or phone number");
                        etEmail.requestFocus();
                    }
                    return;
                }

                if (inputPassword.isEmpty()) {
                    if (etPassword != null) {
                        etPassword.setError("Please enter your password");
                        etPassword.requestFocus();
                    }
                    return;
                }

                // ====================================================
                // 1. EMBEDDED ADMIN LOGIN CHECK
                // ====================================================
                if (inputEmail.equalsIgnoreCase("admin@sarifresh.ph") && inputPassword.equals("admin123")) {
                    activity.registeredName = "SariFresh Store Admin";
                    activity.registeredEmail = "admin@sarifresh.ph";
                    activity.registeredPhone = "09922014615";
                    activity.isPhoneVerified = true; // Pre-verified

                    Toast.makeText(activity, "Welcome Store Admin!", Toast.LENGTH_SHORT).show();
                    activity.showAdminScreen(); // Direct route to Admin Dashboard
                    return;
                }

                // ====================================================
                // 2. REGULAR CUSTOMER LOGIN (FIREBASE AUTHENTICATION)
                // ====================================================
                FirebaseAuth.getInstance().signInWithEmailAndPassword(inputEmail, inputPassword)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                if (user != null) {
                                    String uid = user.getUid();
                                    String dbUrl = MainActivity.DB_URL;

                                    // Fetch user details (name, email) from Realtime Database
                                    FirebaseDatabase.getInstance(dbUrl)
                                            .getReference("users")
                                            .child(uid)
                                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot snapshot) {
                                                    if (snapshot.exists()) {
                                                        String name = snapshot.child("name").getValue(String.class);
                                                        activity.registeredName = (name != null) ? name : "Customer";
                                                        activity.registeredEmail = inputEmail;
                                                    } else {
                                                        activity.registeredName = "Customer";
                                                        activity.registeredEmail = inputEmail;
                                                    }

                                                    Toast.makeText(activity, "Welcome back " + activity.registeredName + "!", Toast.LENGTH_SHORT).show();
                                                    activity.showHomeScreen();
                                                }

                                                @Override
                                                public void onCancelled(DatabaseError error) {
                                                    // Fallback if network drops during profile lookup
                                                    activity.registeredEmail = inputEmail;
                                                    activity.showHomeScreen();
                                                }
                                            });
                                }
                            } else {
                                Toast.makeText(activity, "Incorrect email or password!", Toast.LENGTH_SHORT).show();
                                if (etPassword != null) {
                                    etPassword.setError("Invalid credentials");
                                    etPassword.requestFocus();
                                }
                            }
                        });
            });
        }
    }

    // ====================================================
    // DYNAMIC PASSWORD VISIBILITY TOGGLE HANDLER
    // ====================================================
    private void setupPasswordToggle(EditText editText) {
        editText.setOnTouchListener((v, event) -> {
            final int DRAWABLE_RIGHT = 2;
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (editText.getCompoundDrawables()[DRAWABLE_RIGHT] != null) {
                    if (event.getRawX() >= (editText.getRight() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        if (isPasswordVisible) {
                            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                            isPasswordVisible = false;
                        } else {
                            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                            isPasswordVisible = true;
                        }
                        editText.setSelection(editText.getText().length());
                        return true;
                    }
                }
            }
            return false;
        });
    }

    // ====================================================
    // GOOGLE SIGN-IN LAUNCHER
    // ====================================================
    private void performGoogleSignIn(MainActivity activity) {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("YOUR_ACTUAL_WEB_CLIENT_ID.apps.googleusercontent.com")
                .requestEmail()
                .build();

        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(activity, gso);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        activity.startActivityForResult(signInIntent, 9001);
    }
}